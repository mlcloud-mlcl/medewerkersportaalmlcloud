// prisma/seed.ts
import { PrismaClient, Role } from '@prisma/client'

const prisma = new PrismaClient()

async function main() {
  console.log('🌱 Seeding database...')

  // Seed voorbeeld kennisbank artikelen
  // Voeg hier je eigen Clerk user IDs toe na eerste login
  console.log('✅ Seed voltooid. Voeg gebruikers toe via het beheer paneel.')
}

main()
  .catch((e) => {
    console.error(e)
    process.exit(1)
  })
  .finally(async () => {
    await prisma.$disconnect()
  })
