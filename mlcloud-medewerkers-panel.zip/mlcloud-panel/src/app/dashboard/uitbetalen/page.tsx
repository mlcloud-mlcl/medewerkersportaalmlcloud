// src/app/dashboard/uitbetalen/page.tsx
import { getCurrentUser } from '@/lib/auth'
import { db } from '@/lib/db'
import { redirect } from 'next/navigation'
import { Role } from '@prisma/client'
import { Wallet, ArrowRight, Clock, CheckCircle, XCircle } from 'lucide-react'
import { formatDistanceToNow } from 'date-fns'
import { nl } from 'date-fns/locale'
import { UitbetalingForm } from './UitbetalingForm'

export default async function UitbetalenPage() {
  const user = await getCurrentUser()
  if (!user) redirect('/sign-in')
  if (!user.roles.some((r) => r.role === Role.MARKETING || r.role === Role.BEHEER)) {
    redirect('/dashboard')
  }

  // Goedgekeurde logs die nog niet zijn uitbetaald
  const goedgekeurdeLogs = await db.partnerLog.findMany({
    where: { userId: user.id, status: 'APPROVED' },
    orderBy: { createdAt: 'desc' },
  })

  const totalRobux = goedgekeurdeLogs.reduce((sum, log) => sum + (log.robuxAmount ?? 0), 0)

  // Eerdere uitbetalingen
  const uitbetalingen = await db.payoutRequest.findMany({
    where: { userId: user.id },
    orderBy: { createdAt: 'desc' },
  })

  const statusConfig = {
    PENDING:  { label: 'In behandeling', class: 'badge-yellow', icon: Clock },
    APPROVED: { label: 'Goedgekeurd',   class: 'badge-green',  icon: CheckCircle },
    REJECTED: { label: 'Afgewezen',     class: 'badge-red',    icon: XCircle },
    PAID:     { label: 'Uitbetaald',    class: 'badge-blue',   icon: CheckCircle },
  }

  return (
    <div className="max-w-3xl space-y-6">
      <div>
        <h1 className="text-2xl font-extrabold tracking-tight text-brand-black">Uitbetaling aanvragen</h1>
        <p className="text-brand-muted text-sm mt-1">Jouw goedgekeurde partnerlogs worden hier samengevat. Vraag uitbetaling aan in Robux.</p>
      </div>

      {/* Robux overzicht */}
      <div className="card p-6 flex items-center justify-between">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 bg-brand-blue-light rounded-2xl flex items-center justify-center">
            <Wallet size={24} className="text-brand-blue" />
          </div>
          <div>
            <p className="text-3xl font-extrabold tracking-tight text-brand-black">{totalRobux} <span className="text-lg text-brand-muted font-semibold">Robux</span></p>
            <p className="text-xs text-brand-muted mt-0.5">Beschikbaar uit {goedgekeurdeLogs.length} goedgekeurde partner log{goedgekeurdeLogs.length !== 1 ? 's' : ''}</p>
          </div>
        </div>
      </div>

      {/* Goedgekeurde logs overzicht */}
      {goedgekeurdeLogs.length > 0 && (
        <div className="card overflow-hidden">
          <div className="px-5 py-3 border-b border-brand-border bg-brand-light/50">
            <p className="text-xs font-bold text-brand-muted uppercase tracking-wider">Goedgekeurde partner logs</p>
          </div>
          <div className="divide-y divide-brand-border">
            {goedgekeurdeLogs.map((log) => (
              <div key={log.id} className="px-5 py-3.5 flex items-center justify-between">
                <div>
                  <p className="text-sm font-semibold text-brand-black">{log.serverName}</p>
                  <p className="text-xs text-brand-muted">
                    {{
                      RANGE_50_100: '50–100 leden',
                      RANGE_100_500: '100–500 leden',
                      RANGE_500_PLUS: '500+ leden',
                    }[log.memberRange]}
                  </p>
                </div>
                <p className="text-sm font-bold text-green-600">{log.robuxAmount ?? 0} R$</p>
              </div>
            ))}
            <div className="px-5 py-3 bg-brand-light/50 flex justify-between items-center">
              <p className="text-xs font-bold text-brand-black">Totaal</p>
              <p className="text-sm font-extrabold text-brand-blue">{totalRobux} R$</p>
            </div>
          </div>
        </div>
      )}

      {/* Uitbetaling formulier */}
      {totalRobux > 0 ? (
        <UitbetalingForm totalRobux={totalRobux} />
      ) : (
        <div className="card p-8 text-center text-brand-muted text-sm">
          Je hebt nog geen goedgekeurde partner logs om uit te betalen.
        </div>
      )}

      {/* Eerdere uitbetalingen */}
      {uitbetalingen.length > 0 && (
        <div className="card overflow-hidden">
          <div className="px-5 py-4 border-b border-brand-border">
            <h2 className="font-bold text-sm text-brand-black">Eerdere uitbetalingen</h2>
          </div>
          <div className="divide-y divide-brand-border">
            {uitbetalingen.map((uit) => {
              const sc = statusConfig[uit.status as keyof typeof statusConfig]
              return (
                <div key={uit.id} className="px-5 py-4 flex items-center justify-between">
                  <div>
                    <p className="text-sm font-semibold text-brand-black">{uit.totalRobux} Robux</p>
                    <p className="text-xs text-brand-muted">@{uit.robloxUser} · {formatDistanceToNow(uit.createdAt, { addSuffix: true, locale: nl })}</p>
                    {uit.reviewNote && <p className="text-xs text-brand-muted italic mt-0.5">"{uit.reviewNote}"</p>}
                  </div>
                  <span className={`badge ${sc.class}`}>{sc.label}</span>
                </div>
              )
            })}
          </div>
        </div>
      )}
    </div>
  )
}
