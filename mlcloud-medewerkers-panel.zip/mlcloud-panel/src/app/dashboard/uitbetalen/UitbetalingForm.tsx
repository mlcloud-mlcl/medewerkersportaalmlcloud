// src/app/dashboard/uitbetalen/UitbetalingForm.tsx
'use client'

import { useState } from 'react'
import { ArrowRight, CheckCircle } from 'lucide-react'

export function UitbetalingForm({ totalRobux }: { totalRobux: number }) {
  const [robloxUser, setRobloxUser] = useState('')
  const [loading, setLoading] = useState(false)
  const [success, setSuccess] = useState(false)
  const [error, setError] = useState('')

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!robloxUser.trim()) { setError('Vul je Roblox gebruikersnaam in.'); return }
    setLoading(true); setError('')

    try {
      const res = await fetch('/api/payouts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ robloxUser: robloxUser.trim() }),
      })
      if (!res.ok) throw new Error(await res.text())
      setSuccess(true)
    } catch (err: any) {
      setError(err.message || 'Er is iets misgegaan')
    } finally {
      setLoading(false)
    }
  }

  if (success) {
    return (
      <div className="card p-8 text-center space-y-3">
        <div className="w-12 h-12 bg-green-50 rounded-2xl flex items-center justify-center mx-auto">
          <CheckCircle size={24} className="text-green-500" />
        </div>
        <p className="font-bold text-brand-black">Uitbetalingsverzoek ingediend!</p>
        <p className="text-sm text-brand-muted">Beheer beoordeelt jouw aanvraag van {totalRobux} Robux zo snel mogelijk.</p>
      </div>
    )
  }

  return (
    <form onSubmit={handleSubmit} className="card p-6 space-y-4">
      <h2 className="font-bold text-sm text-brand-black">Uitbetaling aanvragen — {totalRobux} Robux</h2>

      <div>
        <label className="label">Roblox gebruikersnaam</label>
        <input
          value={robloxUser}
          onChange={(e) => setRobloxUser(e.target.value)}
          className="input"
          placeholder="jouw_roblox_naam"
        />
        <p className="text-xs text-brand-muted mt-1.5">
          Hier word het Robux bedrag naartoe gestuurd na goedkeuring.
        </p>
      </div>

      {error && (
        <div className="bg-red-50 border border-red-200 rounded-xl px-4 py-3 text-sm text-red-600">{error}</div>
      )}

      <button
        type="submit"
        disabled={loading}
        className="btn-primary w-full flex items-center justify-center gap-2 py-3"
      >
        {loading ? 'Bezig...' : (<>{totalRobux} Robux aanvragen <ArrowRight size={15} /></>)}
      </button>
    </form>
  )
}
