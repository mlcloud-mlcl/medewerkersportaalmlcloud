// src/app/dashboard/page.tsx
import { redirect } from 'next/navigation'
import { getCurrentUser } from '@/lib/auth'
import { Role } from '@prisma/client'

export default async function DashboardPage() {
  const user = await getCurrentUser()
  if (!user || user.roles.length === 0) redirect('/sign-in')

  // Stuur door naar de juiste dashboard op basis van hoogste rol
  if (user.roles.some((r) => r.role === Role.BEHEER)) {
    redirect('/dashboard/beheer')
  } else if (user.roles.some((r) => r.role === Role.MARKETING)) {
    redirect('/dashboard/marketing')
  } else {
    redirect('/dashboard/support')
  }
}
