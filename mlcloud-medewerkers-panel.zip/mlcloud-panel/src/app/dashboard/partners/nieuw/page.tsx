// src/app/dashboard/partners/nieuw/page.tsx
'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { Upload, Users, Link as LinkIcon, Server, ArrowRight, CheckCircle } from 'lucide-react'

const memberRanges = [
  { value: 'RANGE_50_100',  label: '50 – 100 leden' },
  { value: 'RANGE_100_500', label: '100 – 500 leden' },
  { value: 'RANGE_500_PLUS', label: '500+ leden' },
]

export default function NieuwPartnerLogPage() {
  const router = useRouter()
  const [loading, setLoading] = useState(false)
  const [success, setSuccess] = useState(false)
  const [error, setError] = useState('')

  const [form, setForm] = useState({
    serverName: '',
    serverLink: '',
    memberRange: '',
    screenshotUrl: '',
  })

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    setForm((prev) => ({ ...prev, [e.target.name]: e.target.value }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!form.serverName || !form.serverLink || !form.memberRange || !form.screenshotUrl) {
      setError('Vul alle velden in.')
      return
    }
    setLoading(true)
    setError('')

    try {
      const res = await fetch('/api/partners', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(form),
      })
      if (!res.ok) throw new Error(await res.text())
      setSuccess(true)
      setTimeout(() => router.push('/dashboard/marketing'), 2000)
    } catch (err: any) {
      setError(err.message || 'Er is iets misgegaan')
    } finally {
      setLoading(false)
    }
  }

  if (success) {
    return (
      <div className="max-w-xl mx-auto mt-20 text-center space-y-4">
        <div className="w-16 h-16 bg-green-50 rounded-2xl flex items-center justify-center mx-auto">
          <CheckCircle size={32} className="text-green-500" />
        </div>
        <h2 className="text-xl font-extrabold tracking-tight">Partner gelogd!</h2>
        <p className="text-brand-muted text-sm">Je log is ingediend en wacht op goedkeuring van het beheer.</p>
      </div>
    )
  }

  return (
    <div className="max-w-2xl">
      <div className="mb-6">
        <h1 className="text-2xl font-extrabold tracking-tight text-brand-black">Partner loggen</h1>
        <p className="text-brand-muted text-sm mt-1">Log een nieuwe partnerserver. Beheer keurt het daarna goed en koppelt een Robux bedrag.</p>
      </div>

      <form onSubmit={handleSubmit} className="card p-6 space-y-5">
        {/* Server naam */}
        <div>
          <label className="label">
            <Server size={12} className="inline mr-1" />
            Server naam
          </label>
          <input
            name="serverName"
            value={form.serverName}
            onChange={handleChange}
            className="input"
            placeholder="bijv. ML Gaming Community"
          />
        </div>

        {/* Server link */}
        <div>
          <label className="label">
            <LinkIcon size={12} className="inline mr-1" />
            Discord uitnodiging link
          </label>
          <input
            name="serverLink"
            value={form.serverLink}
            onChange={handleChange}
            className="input"
            placeholder="https://discord.gg/..."
          />
        </div>

        {/* Leden range */}
        <div>
          <label className="label">
            <Users size={12} className="inline mr-1" />
            Aantal leden
          </label>
          <div className="grid grid-cols-3 gap-3">
            {memberRanges.map((range) => (
              <button
                key={range.value}
                type="button"
                onClick={() => setForm((p) => ({ ...p, memberRange: range.value }))}
                className={`py-3 px-3 rounded-xl border text-sm font-semibold transition-all text-center ${
                  form.memberRange === range.value
                    ? 'border-brand-blue bg-brand-blue-light text-brand-blue'
                    : 'border-brand-border bg-white text-brand-black hover:border-brand-blue/40 hover:bg-brand-light'
                }`}
              >
                {range.label}
              </button>
            ))}
          </div>
        </div>

        {/* Screenshot URL */}
        <div>
          <label className="label">
            <Upload size={12} className="inline mr-1" />
            Screenshot URL
          </label>
          <input
            name="screenshotUrl"
            value={form.screenshotUrl}
            onChange={handleChange}
            className="input"
            placeholder="https://imgur.com/... of andere afbeelding URL"
          />
          <p className="text-xs text-brand-muted mt-1.5">
            Upload een screenshot als bewijs (via Imgur, Discord, etc.) en plak de URL hier.
          </p>
        </div>

        {/* Preview screenshot */}
        {form.screenshotUrl && (
          <div className="rounded-xl overflow-hidden border border-brand-border">
            <img src={form.screenshotUrl} alt="Screenshot preview" className="w-full h-40 object-cover" onError={(e) => { (e.target as HTMLImageElement).style.display = 'none' }} />
          </div>
        )}

        {/* Error */}
        {error && (
          <div className="bg-red-50 border border-red-200 rounded-xl px-4 py-3 text-sm text-red-600">
            {error}
          </div>
        )}

        {/* Submit */}
        <button
          type="submit"
          disabled={loading}
          className="btn-primary w-full flex items-center justify-center gap-2 py-3"
        >
          {loading ? 'Bezig met indienen...' : (
            <>Partner log indienen <ArrowRight size={15} /></>
          )}
        </button>
      </form>
    </div>
  )
}
