// src/app/dashboard/beheer/partners/PartnerReviewList.tsx
'use client'

import { useState } from 'react'
import { CheckCircle, XCircle, ExternalLink, Eye, Filter } from 'lucide-react'

type Log = {
  id: string; serverName: string; serverLink: string; memberRange: string
  screenshotUrl: string; status: string; robuxAmount: number | null
  reviewNote: string | null; createdAt: string
  user: { name: string; email: string; avatarUrl: string | null }
}

const memberRangeLabel: Record<string, string> = {
  RANGE_50_100: '50–100 leden', RANGE_100_500: '100–500 leden', RANGE_500_PLUS: '500+ leden',
}

const statusConfig: Record<string, { label: string; class: string }> = {
  PENDING:  { label: 'In behandeling', class: 'badge-yellow' },
  APPROVED: { label: 'Goedgekeurd',   class: 'badge-green'  },
  REJECTED: { label: 'Afgewezen',     class: 'badge-red'    },
}

export function PartnerReviewList({ initialLogs }: { initialLogs: Log[] }) {
  const [logs, setLogs] = useState(initialLogs)
  const [filter, setFilter] = useState<'ALL' | 'PENDING' | 'APPROVED' | 'REJECTED'>('PENDING')
  const [reviewing, setReviewing] = useState<string | null>(null)
  const [form, setForm] = useState({ robuxAmount: '', reviewNote: '' })
  const [loading, setLoading] = useState(false)
  const [previewImg, setPreviewImg] = useState<string | null>(null)

  const filtered = filter === 'ALL' ? logs : logs.filter((l) => l.status === filter)

  const handleReview = async (id: string, status: 'APPROVED' | 'REJECTED') => {
    if (status === 'APPROVED' && !form.robuxAmount) {
      alert('Vul een Robux bedrag in bij goedkeuring.'); return
    }
    setLoading(true)
    try {
      const res = await fetch(`/api/partners/${id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          status,
          robuxAmount: status === 'APPROVED' ? parseInt(form.robuxAmount) : null,
          reviewNote: form.reviewNote,
        }),
      })
      if (!res.ok) throw new Error()
      const updated = await res.json()
      setLogs((prev) => prev.map((l) => l.id === id ? { ...l, ...updated } : l))
      setReviewing(null)
      setForm({ robuxAmount: '', reviewNote: '' })
    } catch {
      alert('Er is iets misgegaan')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="space-y-4">
      {/* Filter tabs */}
      <div className="flex gap-2">
        {(['ALL', 'PENDING', 'APPROVED', 'REJECTED'] as const).map((f) => (
          <button
            key={f}
            onClick={() => setFilter(f)}
            className={`px-4 py-1.5 rounded-lg text-xs font-semibold transition-all border ${
              filter === f
                ? 'bg-brand-black text-white border-brand-black'
                : 'bg-white text-brand-muted border-brand-border hover:bg-brand-light'
            }`}
          >
            {f === 'ALL' ? 'Alles' : statusConfig[f].label}
            <span className="ml-1.5 opacity-60">({logs.filter((l) => f === 'ALL' || l.status === f).length})</span>
          </button>
        ))}
      </div>

      {filtered.length === 0 && (
        <div className="card p-10 text-center text-brand-muted text-sm">Geen partner logs gevonden</div>
      )}

      <div className="space-y-3">
        {filtered.map((log) => (
          <div key={log.id} className="card overflow-hidden">
            <div className="p-5">
              <div className="flex items-start justify-between gap-4">
                <div className="flex-1 min-w-0">
                  {/* Server naam + status */}
                  <div className="flex items-center gap-2 mb-1.5">
                    <h3 className="font-bold text-brand-black">{log.serverName}</h3>
                    <span className={`badge ${statusConfig[log.status]?.class}`}>
                      {statusConfig[log.status]?.label}
                    </span>
                    {log.robuxAmount && (
                      <span className="badge badge-blue">{log.robuxAmount} R$</span>
                    )}
                  </div>

                  {/* Meta info */}
                  <div className="flex flex-wrap gap-x-4 gap-y-1 text-xs text-brand-muted">
                    <span><strong className="text-brand-black">Ingediend door:</strong> {log.user.name}</span>
                    <span><strong className="text-brand-black">Leden:</strong> {memberRangeLabel[log.memberRange]}</span>
                    <a href={log.serverLink} target="_blank" rel="noopener" className="text-brand-blue flex items-center gap-1 hover:underline">
                      <ExternalLink size={11} /> Server link
                    </a>
                  </div>

                  {log.reviewNote && (
                    <p className="text-xs text-brand-muted italic mt-2 bg-brand-light rounded-lg px-3 py-2">
                      Opmerking: "{log.reviewNote}"
                    </p>
                  )}
                </div>

                {/* Screenshot knop + acties */}
                <div className="flex items-center gap-2 flex-shrink-0">
                  <button
                    onClick={() => setPreviewImg(previewImg === log.id ? null : log.id)}
                    className="btn-secondary flex items-center gap-1.5 text-xs"
                  >
                    <Eye size={13} /> Screenshot
                  </button>
                  {log.status === 'PENDING' && (
                    <button
                      onClick={() => setReviewing(reviewing === log.id ? null : log.id)}
                      className="btn-primary text-xs flex items-center gap-1.5"
                    >
                      Beoordelen
                    </button>
                  )}
                </div>
              </div>

              {/* Screenshot preview */}
              {previewImg === log.id && (
                <div className="mt-4 rounded-xl overflow-hidden border border-brand-border">
                  <img src={log.screenshotUrl} alt="Screenshot" className="w-full max-h-64 object-contain bg-brand-light" />
                </div>
              )}

              {/* Review formulier */}
              {reviewing === log.id && (
                <div className="mt-4 border-t border-brand-border pt-4 space-y-3">
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="label">Robux bedrag (bij goedkeuring)</label>
                      <input
                        type="number" min="0"
                        value={form.robuxAmount}
                        onChange={(e) => setForm((p) => ({ ...p, robuxAmount: e.target.value }))}
                        className="input"
                        placeholder="bijv. 500"
                      />
                    </div>
                    <div>
                      <label className="label">Opmerking (optioneel)</label>
                      <input
                        value={form.reviewNote}
                        onChange={(e) => setForm((p) => ({ ...p, reviewNote: e.target.value }))}
                        className="input"
                        placeholder="Toelichting..."
                      />
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <button
                      onClick={() => handleReview(log.id, 'APPROVED')}
                      disabled={loading}
                      className="flex-1 btn-primary flex items-center justify-center gap-1.5 py-2.5"
                    >
                      <CheckCircle size={14} /> Goedkeuren
                    </button>
                    <button
                      onClick={() => handleReview(log.id, 'REJECTED')}
                      disabled={loading}
                      className="flex-1 btn-danger flex items-center justify-center gap-1.5 py-2.5"
                    >
                      <XCircle size={14} /> Afwijzen
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        ))}
      </div>

      {/* Screenshot lightbox */}
      {previewImg && previewImg !== null && (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-6" onClick={() => setPreviewImg(null)}>
          <img
            src={filtered.find((l) => l.id === previewImg)?.screenshotUrl}
            alt="Screenshot fullscreen"
            className="max-w-3xl max-h-[80vh] rounded-2xl shadow-2xl object-contain"
            onClick={(e) => e.stopPropagation()}
          />
        </div>
      )}
    </div>
  )
}
