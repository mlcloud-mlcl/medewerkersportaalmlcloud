// src/app/dashboard/beheer/partners/page.tsx
import { getCurrentUser } from '@/lib/auth'
import { db } from '@/lib/db'
import { redirect } from 'next/navigation'
import { Role } from '@prisma/client'
import { PartnerReviewList } from './PartnerReviewList'

export default async function BeheerPartnersPage() {
  const user = await getCurrentUser()
  if (!user) redirect('/sign-in')
  if (!user.roles.some((r) => r.role === Role.BEHEER)) redirect('/dashboard')

  const logs = await db.partnerLog.findMany({
    orderBy: { createdAt: 'desc' },
    include: { user: { select: { id: true, name: true, email: true, avatarUrl: true } } },
  })

  return (
    <div className="max-w-4xl space-y-6">
      <div>
        <h1 className="text-2xl font-extrabold tracking-tight text-brand-black">Partner log goedkeuren</h1>
        <p className="text-brand-muted text-sm mt-1">Bekijk, goed- of afkeur partner logs en koppel een Robux bedrag.</p>
      </div>
      <PartnerReviewList initialLogs={JSON.parse(JSON.stringify(logs))} />
    </div>
  )
}
