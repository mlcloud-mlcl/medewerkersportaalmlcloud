// src/app/dashboard/beheer/page.tsx
import { getCurrentUser } from '@/lib/auth'
import { db } from '@/lib/db'
import { redirect } from 'next/navigation'
import { Role } from '@prisma/client'
import { Users, CheckSquare, Wallet, TrendingUp, Clock, AlertCircle } from 'lucide-react'
import Link from 'next/link'
import { formatDistanceToNow } from 'date-fns'
import { nl } from 'date-fns/locale'

export default async function BeheerDashboard() {
  const user = await getCurrentUser()
  if (!user) redirect('/sign-in')
  if (!user.roles.some((r) => r.role === Role.BEHEER)) redirect('/dashboard')

  const [
    totalUsers, totalPartnerLogs, pendingLogs, pendingPayouts,
    totalRobuxPaid, recentUsers, recentPendingLogs,
  ] = await Promise.all([
    db.user.count(),
    db.partnerLog.count(),
    db.partnerLog.count({ where: { status: 'PENDING' } }),
    db.payoutRequest.count({ where: { status: 'PENDING' } }),
    db.payoutRequest.aggregate({ where: { status: 'PAID' }, _sum: { totalRobux: true } }),
    db.user.findMany({ orderBy: { createdAt: 'desc' }, take: 5, include: { roles: true } }),
    db.partnerLog.findMany({
      where: { status: 'PENDING' }, orderBy: { createdAt: 'desc' }, take: 5,
      include: { user: { select: { name: true } } },
    }),
  ])

  const hour = new Date().getHours()
  const greeting = hour < 12 ? 'Goedemorgen' : hour < 18 ? 'Goedemiddag' : 'Goedenavond'

  const memberRangeLabel: Record<string, string> = {
    RANGE_50_100: '50–100 leden',
    RANGE_100_500: '100–500 leden',
    RANGE_500_PLUS: '500+ leden',
  }

  return (
    <div className="space-y-6 max-w-5xl">
      <div>
        <h1 className="text-2xl font-extrabold tracking-tight text-brand-black">
          {greeting}, {user.name.split(' ')[0]} 👋
        </h1>
        <p className="text-brand-muted text-sm mt-1">Beheer overzicht — alles in één oogopslag.</p>
      </div>

      {/* Alerts */}
      {(pendingLogs > 0 || pendingPayouts > 0) && (
        <div className="space-y-2">
          {pendingLogs > 0 && (
            <Link href="/dashboard/beheer/partners" className="flex items-center gap-3 bg-yellow-50 border border-yellow-200 rounded-xl px-4 py-3 hover:bg-yellow-100 transition-colors">
              <AlertCircle size={16} className="text-yellow-600 flex-shrink-0" />
              <p className="text-sm font-semibold text-yellow-800">{pendingLogs} partner log{pendingLogs !== 1 ? 's' : ''} wacht op goedkeuring →</p>
            </Link>
          )}
          {pendingPayouts > 0 && (
            <Link href="/dashboard/beheer/uitbetalingen" className="flex items-center gap-3 bg-brand-blue-light border border-brand-blue/30 rounded-xl px-4 py-3 hover:bg-brand-blue/10 transition-colors">
              <AlertCircle size={16} className="text-brand-blue flex-shrink-0" />
              <p className="text-sm font-semibold text-brand-blue">{pendingPayouts} uitbetaling{pendingPayouts !== 1 ? 'en' : ''} wacht op verwerking →</p>
            </Link>
          )}
        </div>
      )}

      {/* Stats grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { label: 'Totaal medewerkers', value: totalUsers, icon: Users, color: 'bg-brand-blue-light text-brand-blue' },
          { label: 'Partner logs totaal', value: totalPartnerLogs, icon: TrendingUp, color: 'bg-purple-50 text-purple-600' },
          { label: 'In behandeling', value: pendingLogs + pendingPayouts, icon: Clock, color: 'bg-yellow-50 text-yellow-600' },
          { label: 'Robux uitbetaald', value: `${totalRobuxPaid._sum.totalRobux ?? 0} R$`, icon: Wallet, color: 'bg-green-50 text-green-600' },
        ].map((s) => (
          <div key={s.label} className="card p-5">
            <div className={`w-9 h-9 rounded-xl flex items-center justify-center mb-3 ${s.color}`}>
              <s.icon size={18} />
            </div>
            <p className="text-2xl font-extrabold text-brand-black">{s.value}</p>
            <p className="text-xs text-brand-muted mt-0.5">{s.label}</p>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-2 gap-5">
        {/* Pending partner logs */}
        <div className="card overflow-hidden">
          <div className="px-5 py-4 border-b border-brand-border flex items-center justify-between">
            <h2 className="font-bold text-sm text-brand-black flex items-center gap-2">
              <CheckSquare size={15} className="text-brand-blue" /> Openstaande logs
            </h2>
            <Link href="/dashboard/beheer/partners" className="text-xs text-brand-blue font-semibold hover:underline">Alle →</Link>
          </div>
          {recentPendingLogs.length === 0 ? (
            <div className="p-6 text-center text-brand-muted text-xs">Geen openstaande logs</div>
          ) : (
            <div className="divide-y divide-brand-border">
              {recentPendingLogs.map((log) => (
                <div key={log.id} className="px-5 py-3.5">
                  <p className="text-sm font-semibold text-brand-black truncate">{log.serverName}</p>
                  <p className="text-xs text-brand-muted">{log.user.name} · {memberRangeLabel[log.memberRange]}</p>
                  <p className="text-[10px] text-brand-muted mt-0.5">{formatDistanceToNow(log.createdAt, { addSuffix: true, locale: nl })}</p>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Recente gebruikers */}
        <div className="card overflow-hidden">
          <div className="px-5 py-4 border-b border-brand-border flex items-center justify-between">
            <h2 className="font-bold text-sm text-brand-black flex items-center gap-2">
              <Users size={15} className="text-brand-blue" /> Recente medewerkers
            </h2>
            <Link href="/dashboard/beheer/gebruikers" className="text-xs text-brand-blue font-semibold hover:underline">Beheer →</Link>
          </div>
          <div className="divide-y divide-brand-border">
            {recentUsers.map((u) => (
              <div key={u.id} className="px-5 py-3 flex items-center gap-3">
                <div className="w-7 h-7 rounded-full bg-brand-blue-light flex items-center justify-center flex-shrink-0">
                  <span className="text-brand-blue text-[10px] font-bold">{u.name.charAt(0).toUpperCase()}</span>
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-semibold text-brand-black truncate">{u.name}</p>
                  <div className="flex gap-1 mt-0.5">
                    {u.roles.map((r) => (
                      <span key={r.role} className={`text-[9px] font-bold px-1.5 py-0.5 rounded-full ${
                        r.role === 'BEHEER' ? 'bg-purple-50 text-purple-700' :
                        r.role === 'MARKETING' ? 'bg-green-50 text-green-700' : 'bg-yellow-50 text-yellow-700'
                      }`}>{r.role}</span>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
