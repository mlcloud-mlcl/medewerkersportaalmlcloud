// src/app/dashboard/beheer/uitbetalingen/page.tsx
import { getCurrentUser } from '@/lib/auth'
import { db } from '@/lib/db'
import { redirect } from 'next/navigation'
import { Role } from '@prisma/client'
import { UitbetalingenReviewList } from './UitbetalingenReviewList'

export default async function BeheerUitbetalingenPage() {
  const user = await getCurrentUser()
  if (!user) redirect('/sign-in')
  if (!user.roles.some((r) => r.role === Role.BEHEER)) redirect('/dashboard')

  const payouts = await db.payoutRequest.findMany({
    orderBy: { createdAt: 'desc' },
    include: {
      user: { select: { name: true, email: true, avatarUrl: true } },
    },
  })

  return (
    <div className="max-w-4xl space-y-6">
      <div>
        <h1 className="text-2xl font-extrabold tracking-tight text-brand-black">Uitbetalingen beheren</h1>
        <p className="text-brand-muted text-sm mt-1">Goedkeuren, afwijzen of markeren als uitbetaald.</p>
      </div>
      <UitbetalingenReviewList initialPayouts={JSON.parse(JSON.stringify(payouts))} />
    </div>
  )
}
