// src/app/dashboard/beheer/uitbetalingen/UitbetalingenReviewList.tsx
'use client'

import { useState } from 'react'
import { CheckCircle, XCircle, Banknote, Clock, Filter } from 'lucide-react'
import { formatDistanceToNow } from 'date-fns'
import { nl } from 'date-fns/locale'

type Payout = {
  id: string; robloxUser: string; totalRobux: number; status: string
  reviewNote: string | null; createdAt: string; paidAt: string | null
  user: { name: string; email: string; avatarUrl: string | null }
}

const statusConfig: Record<string, { label: string; class: string; icon: any }> = {
  PENDING:  { label: 'In behandeling', class: 'badge-yellow', icon: Clock },
  APPROVED: { label: 'Goedgekeurd',   class: 'badge-green',  icon: CheckCircle },
  REJECTED: { label: 'Afgewezen',     class: 'badge-red',    icon: XCircle },
  PAID:     { label: 'Uitbetaald',    class: 'badge-blue',   icon: Banknote },
}

export function UitbetalingenReviewList({ initialPayouts }: { initialPayouts: Payout[] }) {
  const [payouts, setPayouts] = useState(initialPayouts)
  const [filter, setFilter] = useState<string>('PENDING')
  const [reviewing, setReviewing] = useState<string | null>(null)
  const [reviewNote, setReviewNote] = useState('')
  const [loading, setLoading] = useState(false)

  const filtered = filter === 'ALL' ? payouts : payouts.filter((p) => p.status === filter)

  const handleAction = async (id: string, status: string) => {
    setLoading(true)
    try {
      const res = await fetch(`/api/payouts/${id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status, reviewNote }),
      })
      if (!res.ok) throw new Error()
      const updated = await res.json()
      setPayouts((prev) => prev.map((p) => p.id === id ? { ...p, ...updated } : p))
      setReviewing(null)
      setReviewNote('')
    } catch {
      alert('Er is iets misgegaan')
    } finally {
      setLoading(false)
    }
  }

  const totalPending = payouts.filter((p) => p.status === 'PENDING').length
  const totalPendingRobux = payouts
    .filter((p) => p.status === 'PENDING')
    .reduce((s, p) => s + p.totalRobux, 0)
  const totalPaid = payouts
    .filter((p) => p.status === 'PAID')
    .reduce((s, p) => s + p.totalRobux, 0)

  return (
    <div className="space-y-4">
      {/* Overzicht stats */}
      <div className="grid grid-cols-3 gap-4">
        <div className="card p-4">
          <p className="text-xs text-brand-muted mb-1">Openstaand</p>
          <p className="text-xl font-extrabold text-brand-black">{totalPending}</p>
          <p className="text-xs text-brand-muted">{totalPendingRobux} R$ te verwerken</p>
        </div>
        <div className="card p-4">
          <p className="text-xs text-brand-muted mb-1">Totaal uitbetaald</p>
          <p className="text-xl font-extrabold text-green-600">{totalPaid} R$</p>
          <p className="text-xs text-brand-muted">{payouts.filter((p) => p.status === 'PAID').length} aanvragen</p>
        </div>
        <div className="card p-4">
          <p className="text-xs text-brand-muted mb-1">Alle aanvragen</p>
          <p className="text-xl font-extrabold text-brand-black">{payouts.length}</p>
          <p className="text-xs text-brand-muted">totaal ontvangen</p>
        </div>
      </div>

      {/* Filter tabs */}
      <div className="flex gap-2 flex-wrap">
        {(['ALL', 'PENDING', 'APPROVED', 'REJECTED', 'PAID'] as const).map((f) => (
          <button
            key={f}
            onClick={() => setFilter(f)}
            className={`px-4 py-1.5 rounded-lg text-xs font-semibold transition-all border ${
              filter === f
                ? 'bg-brand-black text-white border-brand-black'
                : 'bg-white text-brand-muted border-brand-border hover:bg-brand-light'
            }`}
          >
            {f === 'ALL' ? 'Alles' : statusConfig[f].label}
            <span className="ml-1.5 opacity-60">
              ({payouts.filter((p) => f === 'ALL' || p.status === f).length})
            </span>
          </button>
        ))}
      </div>

      {filtered.length === 0 && (
        <div className="card p-10 text-center text-brand-muted text-sm">Geen uitbetalingen gevonden</div>
      )}

      <div className="space-y-3">
        {filtered.map((payout) => {
          const sc = statusConfig[payout.status]
          const isReviewing = reviewing === payout.id
          return (
            <div key={payout.id} className="card overflow-hidden">
              <div className="p-5">
                <div className="flex items-start gap-4">
                  {/* Avatar */}
                  <div className="w-10 h-10 rounded-full bg-brand-blue-light flex items-center justify-center flex-shrink-0 overflow-hidden">
                    {payout.user.avatarUrl ? (
                      <img src={payout.user.avatarUrl} alt="" className="w-full h-full object-cover" />
                    ) : (
                      <span className="text-brand-blue font-bold text-sm">
                        {payout.user.name.charAt(0).toUpperCase()}
                      </span>
                    )}
                  </div>

                  {/* Info */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <p className="font-bold text-brand-black">{payout.user.name}</p>
                      <span className={`badge ${sc.class}`}>{sc.label}</span>
                    </div>
                    <div className="flex flex-wrap gap-x-4 gap-y-1 text-xs text-brand-muted">
                      <span>
                        <strong className="text-brand-black">Roblox:</strong> @{payout.robloxUser}
                      </span>
                      <span>
                        <strong className="text-brand-black">Bedrag:</strong>{' '}
                        <span className="text-green-600 font-bold">{payout.totalRobux} R$</span>
                      </span>
                      <span>
                        {formatDistanceToNow(new Date(payout.createdAt), { addSuffix: true, locale: nl })}
                      </span>
                    </div>
                    {payout.reviewNote && (
                      <p className="text-xs text-brand-muted italic mt-2 bg-brand-light rounded-lg px-3 py-1.5">
                        "{payout.reviewNote}"
                      </p>
                    )}
                  </div>

                  {/* Actie knop */}
                  {payout.status === 'PENDING' && (
                    <button
                      onClick={() => setReviewing(isReviewing ? null : payout.id)}
                      className="btn-primary text-xs flex-shrink-0"
                    >
                      Beoordelen
                    </button>
                  )}
                  {payout.status === 'APPROVED' && (
                    <button
                      onClick={() => handleAction(payout.id, 'PAID')}
                      disabled={loading}
                      className="flex items-center gap-1.5 px-3 py-2 bg-green-500 text-white rounded-lg text-xs font-semibold hover:bg-green-600 transition-colors flex-shrink-0"
                    >
                      <Banknote size={13} /> Markeer uitbetaald
                    </button>
                  )}
                </div>

                {/* Review formulier */}
                {isReviewing && (
                  <div className="mt-4 border-t border-brand-border pt-4 space-y-3">
                    <div>
                      <label className="label">Opmerking (optioneel)</label>
                      <input
                        value={reviewNote}
                        onChange={(e) => setReviewNote(e.target.value)}
                        className="input"
                        placeholder="Toelichting bij beslissing..."
                      />
                    </div>
                    <div className="flex gap-2">
                      <button
                        onClick={() => handleAction(payout.id, 'APPROVED')}
                        disabled={loading}
                        className="flex-1 btn-primary flex items-center justify-center gap-1.5 py-2.5"
                      >
                        <CheckCircle size={14} /> Goedkeuren
                      </button>
                      <button
                        onClick={() => handleAction(payout.id, 'REJECTED')}
                        disabled={loading}
                        className="flex-1 btn-danger flex items-center justify-center gap-1.5 py-2.5"
                      >
                        <XCircle size={14} /> Afwijzen
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </div>
          )
        })}
      </div>
    </div>
  )
}
