// src/app/dashboard/beheer/gebruikers/GebruikersList.tsx
'use client'

import { useState } from 'react'
import { User2, Shield, BarChart2, HeadphonesIcon, ChevronDown, ChevronUp, Save, Trash2 } from 'lucide-react'

type UserRole = {
  id: string; role: string
  canPostAnnouncementsSupport: boolean; canPostAnnouncementsMarketing: boolean
  canEditKnowledgeSupport: boolean; canEditKnowledgeMarketing: boolean
}

type User = {
  id: string; name: string; email: string; avatarUrl: string | null
  createdAt: string; roles: UserRole[]
}

const ROLES = [
  { value: 'SUPPORT', label: 'Support', icon: HeadphonesIcon, color: 'bg-yellow-50 text-yellow-700', border: 'border-yellow-200' },
  { value: 'MARKETING', label: 'Marketing', icon: BarChart2, color: 'bg-green-50 text-green-700', border: 'border-green-200' },
  { value: 'BEHEER', label: 'Beheer', icon: Shield, color: 'bg-purple-50 text-purple-700', border: 'border-purple-200' },
]

export function GebruikersList({ initialUsers, currentUserId }: { initialUsers: User[], currentUserId: string }) {
  const [users, setUsers] = useState(initialUsers)
  const [expanded, setExpanded] = useState<string | null>(null)
  const [saving, setSaving] = useState<string | null>(null)

  const toggleExpand = (id: string) => setExpanded(expanded === id ? null : id)

  const toggleRole = async (userId: string, role: string) => {
    const user = users.find((u) => u.id === userId)!
    const hasRole = user.roles.some((r) => r.role === role)

    setSaving(userId)
    try {
      const res = await fetch(`/api/users/${userId}/roles`, {
        method: hasRole ? 'DELETE' : 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ role }),
      })
      if (!res.ok) throw new Error()
      const updatedUser = await res.json()
      setUsers((prev) => prev.map((u) => u.id === userId ? updatedUser : u))
    } catch {
      alert('Fout bij opslaan')
    } finally {
      setSaving(null)
    }
  }

  const updatePermission = async (userId: string, permission: string, value: boolean) => {
    setSaving(userId)
    try {
      const res = await fetch(`/api/users/${userId}/permissions`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ permission, value }),
      })
      if (!res.ok) throw new Error()
      const updatedUser = await res.json()
      setUsers((prev) => prev.map((u) => u.id === userId ? updatedUser : u))
    } catch {
      alert('Fout bij opslaan')
    } finally {
      setSaving(null)
    }
  }

  return (
    <div className="space-y-3">
      <p className="text-xs text-brand-muted">{users.length} medewerker{users.length !== 1 ? 's' : ''} geregistreerd</p>

      {users.map((user) => {
        const isExpanded = expanded === user.id
        const isSelf = user.id === currentUserId

        return (
          <div key={user.id} className="card overflow-hidden">
            {/* Hoofd rij */}
            <div className="px-5 py-4 flex items-center gap-4">
              {/* Avatar */}
              <div className="w-9 h-9 rounded-full bg-brand-blue-light flex items-center justify-center flex-shrink-0 overflow-hidden">
                {user.avatarUrl ? (
                  <img src={user.avatarUrl} alt={user.name} className="w-full h-full object-cover" />
                ) : (
                  <span className="text-brand-blue text-sm font-bold">{user.name.charAt(0).toUpperCase()}</span>
                )}
              </div>

              {/* Naam + email */}
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <p className="font-semibold text-sm text-brand-black truncate">{user.name}</p>
                  {isSelf && <span className="badge badge-blue text-[10px]">Jij</span>}
                </div>
                <p className="text-xs text-brand-muted truncate">{user.email}</p>
              </div>

              {/* Rollen badges */}
              <div className="flex gap-1.5 flex-shrink-0">
                {user.roles.length === 0 ? (
                  <span className="badge badge-gray">Geen rollen</span>
                ) : user.roles.map((r) => {
                  const rc = ROLES.find((x) => x.value === r.role)
                  return rc ? (
                    <span key={r.role} className={`badge ${rc.color}`}>{rc.label}</span>
                  ) : null
                })}
              </div>

              {/* Expand knop */}
              <button
                onClick={() => toggleExpand(user.id)}
                className="w-8 h-8 flex items-center justify-center rounded-lg hover:bg-brand-light text-brand-muted transition-colors"
              >
                {isExpanded ? <ChevronUp size={15} /> : <ChevronDown size={15} />}
              </button>
            </div>

            {/* Uitklap: rollen & permissies */}
            {isExpanded && (
              <div className="border-t border-brand-border px-5 py-4 bg-brand-light/30 space-y-5">
                {/* Rollen toewijzen */}
                <div>
                  <p className="text-xs font-bold text-brand-black mb-3">Rollen</p>
                  <div className="grid grid-cols-3 gap-3">
                    {ROLES.map((role) => {
                      const hasRole = user.roles.some((r) => r.role === role.value)
                      return (
                        <button
                          key={role.value}
                          onClick={() => toggleRole(user.id, role.value)}
                          disabled={saving === user.id}
                          className={`flex items-center gap-2.5 px-4 py-3 rounded-xl border text-sm font-semibold transition-all ${
                            hasRole
                              ? `${role.color} ${role.border}`
                              : 'bg-white text-brand-muted border-brand-border hover:bg-brand-light'
                          }`}
                        >
                          <role.icon size={14} />
                          {role.label}
                        </button>
                      )
                    })}
                  </div>
                </div>

                {/* Permissies */}
                <div>
                  <p className="text-xs font-bold text-brand-black mb-3">Permissies</p>
                  <div className="space-y-2.5">
                    {[
                      { key: 'canPostAnnouncementsSupport', label: 'Aankondigingen plaatsen (Support)', dept: 'SUPPORT' },
                      { key: 'canPostAnnouncementsMarketing', label: 'Aankondigingen plaatsen (Marketing)', dept: 'MARKETING' },
                      { key: 'canEditKnowledgeSupport', label: 'Kennisbank bewerken (Support)', dept: 'SUPPORT' },
                      { key: 'canEditKnowledgeMarketing', label: 'Kennisbank bewerken (Marketing)', dept: 'MARKETING' },
                    ].map((perm) => {
                      const roleForPerm = user.roles.find((r) => r.role === perm.dept || r.role === 'BEHEER')
                      const currentValue = user.roles.some((r) => (r as any)[perm.key])
                      return (
                        <div key={perm.key} className="flex items-center justify-between bg-white rounded-xl px-4 py-3 border border-brand-border">
                          <div>
                            <p className="text-sm font-medium text-brand-black">{perm.label}</p>
                            <p className="text-xs text-brand-muted">Afdeling: {perm.dept}</p>
                          </div>
                          <button
                            onClick={() => updatePermission(user.id, perm.key, !currentValue)}
                            disabled={saving === user.id}
                            className={`relative w-11 h-6 rounded-full transition-all flex-shrink-0 ${
                              currentValue ? 'bg-brand-blue' : 'bg-brand-border'
                            }`}
                          >
                            <div className={`absolute top-0.5 w-5 h-5 bg-white rounded-full shadow transition-transform ${
                              currentValue ? 'translate-x-5' : 'translate-x-0.5'
                            }`} />
                          </button>
                        </div>
                      )
                    })}
                  </div>
                </div>

                {saving === user.id && (
                  <p className="text-xs text-brand-blue animate-pulse">Opslaan...</p>
                )}
              </div>
            )}
          </div>
        )
      })}
    </div>
  )
}
