// src/app/dashboard/beheer/gebruikers/page.tsx
import { getCurrentUser } from '@/lib/auth'
import { db } from '@/lib/db'
import { redirect } from 'next/navigation'
import { Role } from '@prisma/client'
import { GebruikersList } from './GebruikersList'

export default async function GebruikersPage() {
  const user = await getCurrentUser()
  if (!user) redirect('/sign-in')
  if (!user.roles.some((r) => r.role === Role.BEHEER)) redirect('/dashboard')

  const users = await db.user.findMany({
    orderBy: { createdAt: 'desc' },
    include: { roles: true },
  })

  return (
    <div className="max-w-4xl space-y-6">
      <div>
        <h1 className="text-2xl font-extrabold tracking-tight text-brand-black">Gebruikers beheren</h1>
        <p className="text-brand-muted text-sm mt-1">Voeg medewerkers toe, beheer rollen en stel permissies in per afdeling.</p>
      </div>
      <GebruikersList initialUsers={JSON.parse(JSON.stringify(users))} currentUserId={user.id} />
    </div>
  )
}
