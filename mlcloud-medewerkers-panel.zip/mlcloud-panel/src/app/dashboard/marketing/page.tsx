// src/app/dashboard/marketing/page.tsx
import { getCurrentUser } from '@/lib/auth'
import { db } from '@/lib/db'
import { redirect } from 'next/navigation'
import { Role } from '@prisma/client'
import { Users, Wallet, Clock, CheckCircle, XCircle, TrendingUp } from 'lucide-react'
import { formatDistanceToNow } from 'date-fns'
import { nl } from 'date-fns/locale'
import Link from 'next/link'

export default async function MarketingDashboard() {
  const user = await getCurrentUser()
  if (!user) redirect('/sign-in')
  if (!user.roles.some((r) => r.role === Role.MARKETING || r.role === Role.BEHEER)) {
    redirect('/dashboard')
  }

  const [totalLogs, pendingLogs, approvedLogs, rejectedLogs, recentLogs] = await Promise.all([
    db.partnerLog.count({ where: { userId: user.id } }),
    db.partnerLog.count({ where: { userId: user.id, status: 'PENDING' } }),
    db.partnerLog.count({ where: { userId: user.id, status: 'APPROVED' } }),
    db.partnerLog.count({ where: { userId: user.id, status: 'REJECTED' } }),
    db.partnerLog.findMany({
      where: { userId: user.id },
      orderBy: { createdAt: 'desc' },
      take: 6,
    }),
  ])

  // Bereken totaal robux van goedgekeurde logs die nog niet uitbetaald zijn
  const openRobux = await db.partnerLog.aggregate({
    where: { userId: user.id, status: 'APPROVED' },
    _sum: { robuxAmount: true },
  })

  const hour = new Date().getHours()
  const greeting = hour < 12 ? 'Goedemorgen' : hour < 18 ? 'Goedemiddag' : 'Goedenavond'

  const memberRangeLabel = {
    RANGE_50_100: '50–100 leden',
    RANGE_100_500: '100–500 leden',
    RANGE_500_PLUS: '500+ leden',
  }

  const statusConfig = {
    PENDING:  { label: 'In behandeling', class: 'badge-yellow', icon: Clock },
    APPROVED: { label: 'Goedgekeurd',   class: 'badge-green',  icon: CheckCircle },
    REJECTED: { label: 'Afgewezen',     class: 'badge-red',    icon: XCircle },
  }

  return (
    <div className="space-y-6 max-w-5xl">
      <div>
        <h1 className="text-2xl font-extrabold tracking-tight text-brand-black">
          {greeting}, {user.name.split(' ')[0]} 👋
        </h1>
        <p className="text-brand-muted text-sm mt-1">Jouw marketing overzicht — partners, logs en uitbetalingen.</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="card p-5">
          <div className="w-9 h-9 rounded-xl bg-brand-blue-light text-brand-blue flex items-center justify-center mb-3">
            <Users size={18} />
          </div>
          <p className="text-2xl font-extrabold text-brand-black">{totalLogs}</p>
          <p className="text-xs text-brand-muted mt-0.5">Totaal gelogd</p>
        </div>
        <div className="card p-5">
          <div className="w-9 h-9 rounded-xl bg-yellow-50 text-yellow-600 flex items-center justify-center mb-3">
            <Clock size={18} />
          </div>
          <p className="text-2xl font-extrabold text-brand-black">{pendingLogs}</p>
          <p className="text-xs text-brand-muted mt-0.5">In behandeling</p>
        </div>
        <div className="card p-5">
          <div className="w-9 h-9 rounded-xl bg-green-50 text-green-600 flex items-center justify-center mb-3">
            <CheckCircle size={18} />
          </div>
          <p className="text-2xl font-extrabold text-brand-black">{approvedLogs}</p>
          <p className="text-xs text-brand-muted mt-0.5">Goedgekeurd</p>
        </div>
        <div className="card p-5">
          <div className="w-9 h-9 rounded-xl bg-purple-50 text-purple-600 flex items-center justify-center mb-3">
            <Wallet size={18} />
          </div>
          <p className="text-2xl font-extrabold text-brand-black">{openRobux._sum.robuxAmount ?? 0}</p>
          <p className="text-xs text-brand-muted mt-0.5">Robux beschikbaar</p>
        </div>
      </div>

      {/* Snelle acties */}
      <div className="grid grid-cols-2 gap-4">
        <Link href="/dashboard/partners/nieuw" className="card p-5 hover:border-brand-blue/40 hover:bg-brand-blue-light/30 transition-all group">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-brand-blue-light text-brand-blue flex items-center justify-center group-hover:bg-brand-blue group-hover:text-white transition-all">
              <Users size={18} />
            </div>
            <div>
              <p className="font-bold text-sm text-brand-black">Partner loggen</p>
              <p className="text-xs text-brand-muted">Nieuwe partner toevoegen</p>
            </div>
          </div>
        </Link>
        <Link href="/dashboard/uitbetalen" className="card p-5 hover:border-green-300 hover:bg-green-50/50 transition-all group">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-green-50 text-green-600 flex items-center justify-center group-hover:bg-green-500 group-hover:text-white transition-all">
              <Wallet size={18} />
            </div>
            <div>
              <p className="font-bold text-sm text-brand-black">Uitbetaling aanvragen</p>
              <p className="text-xs text-brand-muted">{openRobux._sum.robuxAmount ?? 0} Robux beschikbaar</p>
            </div>
          </div>
        </Link>
      </div>

      {/* Recente logs */}
      <div className="card overflow-hidden">
        <div className="px-5 py-4 border-b border-brand-border flex items-center justify-between">
          <h2 className="font-bold text-sm text-brand-black flex items-center gap-2">
            <TrendingUp size={15} className="text-brand-blue" />
            Jouw recente partner logs
          </h2>
          <Link href="/dashboard/partners" className="text-xs text-brand-blue font-semibold hover:underline">
            Alle logs →
          </Link>
        </div>
        {recentLogs.length === 0 ? (
          <div className="p-10 text-center text-brand-muted text-sm">
            Je hebt nog geen partner logs. <Link href="/dashboard/partners/nieuw" className="text-brand-blue font-semibold">Log je eerste partner →</Link>
          </div>
        ) : (
          <div className="divide-y divide-brand-border">
            {recentLogs.map((log) => {
              const sc = statusConfig[log.status as keyof typeof statusConfig]
              return (
                <div key={log.id} className="px-5 py-4 hover:bg-brand-light/40 transition-colors">
                  <div className="flex items-center justify-between gap-3">
                    <div className="flex-1 min-w-0">
                      <p className="font-semibold text-sm text-brand-black truncate">{log.serverName}</p>
                      <p className="text-xs text-brand-muted mt-0.5">
                        {memberRangeLabel[log.memberRange as keyof typeof memberRangeLabel]}
                        {log.robuxAmount ? ` · ${log.robuxAmount} Robux` : ''}
                      </p>
                    </div>
                    <div className="flex items-center gap-2 flex-shrink-0">
                      <span className={`badge ${sc.class}`}>{sc.label}</span>
                      <span className="text-[10px] text-brand-muted">
                        {formatDistanceToNow(log.createdAt, { addSuffix: true, locale: nl })}
                      </span>
                    </div>
                  </div>
                </div>
              )
            })}
          </div>
        )}
      </div>
    </div>
  )
}
