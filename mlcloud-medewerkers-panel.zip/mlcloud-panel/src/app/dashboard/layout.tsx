// src/app/dashboard/layout.tsx
import { redirect } from 'next/navigation'
import { getCurrentUser } from '@/lib/auth'
import { Header } from '@/components/layout/Header'
import { Sidebar } from '@/components/layout/Sidebar'

export default async function DashboardLayout({ children }: { children: React.ReactNode }) {
  const user = await getCurrentUser()

  // Geen account in DB? Stuur naar sign-in
  if (!user) redirect('/sign-in')

  // Geen rollen? Geen toegang (wacht op beheerder)
  if (user.roles.length === 0) {
    return (
      <main className="min-h-screen flex items-center justify-center bg-brand-light">
        <div className="card p-10 max-w-md w-full text-center space-y-4">
          <div className="w-14 h-14 bg-yellow-50 rounded-2xl flex items-center justify-center mx-auto">
            <svg className="w-7 h-7 text-yellow-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
            </svg>
          </div>
          <h1 className="text-xl font-extrabold tracking-tight">Geen toegang</h1>
          <p className="text-brand-muted text-sm leading-relaxed">
            Je account is aangemaakt maar heeft nog geen rollen. Neem contact op met een beheerder om toegang te krijgen.
          </p>
          <p className="text-xs text-brand-muted bg-brand-light rounded-lg px-4 py-2">
            Je bent ingelogd als <strong>{user.email}</strong>
          </p>
        </div>
      </main>
    )
  }

  const roleNames = user.roles.map((r) => r.role)
  const notifCount = 0 // later: ophalen uit DB

  return (
    <div className="min-h-screen flex flex-col">
      <Header
        userName={user.name}
        roles={roleNames}
        notificationCount={notifCount}
      />
      <div className="flex flex-1">
        <Sidebar userRoles={roleNames} />
        <main className="flex-1 p-7 min-h-[calc(100vh-56px)] overflow-y-auto">
          {children}
        </main>
      </div>
    </div>
  )
}
