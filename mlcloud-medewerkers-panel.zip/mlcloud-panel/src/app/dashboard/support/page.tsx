// src/app/dashboard/support/page.tsx
import { getCurrentUser } from '@/lib/auth'
import { db } from '@/lib/db'
import { redirect } from 'next/navigation'
import { Role } from '@prisma/client'
import { MessageSquare, BookOpen, Megaphone, TrendingUp } from 'lucide-react'
import { formatDistanceToNow } from 'date-fns'
import { nl } from 'date-fns/locale'

export default async function SupportDashboard() {
  const user = await getCurrentUser()
  if (!user) redirect('/sign-in')
  if (!user.roles.some((r) => r.role === Role.SUPPORT || r.role === Role.BEHEER)) {
    redirect('/dashboard')
  }

  // Haal statistieken op
  const [articleCount, announcementCount, recentAnnouncements] = await Promise.all([
    db.knowledgeArticle.count({ where: { department: { in: ['SUPPORT', 'ALL'] }, published: true } }),
    db.announcement.count({ where: { department: { in: ['SUPPORT', 'ALL'] } } }),
    db.announcement.findMany({
      where: { department: { in: ['SUPPORT', 'ALL'] } },
      orderBy: { createdAt: 'desc' },
      take: 5,
      include: { author: true },
    }),
  ])

  const stats = [
    { label: 'Kennisbank artikelen', value: articleCount, icon: BookOpen, color: 'bg-brand-blue-light text-brand-blue' },
    { label: 'Aankondigingen', value: announcementCount, icon: Megaphone, color: 'bg-yellow-50 text-yellow-600' },
  ]

  const hour = new Date().getHours()
  const greeting = hour < 12 ? 'Goedemorgen' : hour < 18 ? 'Goedemiddag' : 'Goedenavond'

  return (
    <div className="space-y-6 max-w-5xl">
      {/* Welkom header */}
      <div>
        <h1 className="text-2xl font-extrabold tracking-tight text-brand-black">
          {greeting}, {user.name.split(' ')[0]} 👋
        </h1>
        <p className="text-brand-muted text-sm mt-1">Hier is een overzicht van jouw support werkplek.</p>
      </div>

      {/* Stat kaarten */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {stats.map((stat) => (
          <div key={stat.label} className="card p-5">
            <div className={`w-9 h-9 rounded-xl flex items-center justify-center mb-3 ${stat.color}`}>
              <stat.icon size={18} />
            </div>
            <p className="text-2xl font-extrabold text-brand-black">{stat.value}</p>
            <p className="text-xs text-brand-muted mt-0.5">{stat.label}</p>
          </div>
        ))}

        {/* Welkom kaart */}
        <div className="card p-5 col-span-2 bg-brand-blue border-brand-blue flex items-center gap-4">
          <div className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center flex-shrink-0">
            <TrendingUp size={20} className="text-white" />
          </div>
          <div>
            <p className="text-white font-bold text-sm">Support afdeling</p>
            <p className="text-white/70 text-xs mt-0.5">Je bent ingelogd als support medewerker</p>
          </div>
        </div>
      </div>

      {/* Recente aankondigingen */}
      <div className="card overflow-hidden">
        <div className="px-5 py-4 border-b border-brand-border flex items-center justify-between">
          <h2 className="font-bold text-sm text-brand-black flex items-center gap-2">
            <Megaphone size={15} className="text-brand-blue" />
            Recente aankondigingen
          </h2>
        </div>
        {recentAnnouncements.length === 0 ? (
          <div className="p-10 text-center text-brand-muted text-sm">
            Nog geen aankondigingen
          </div>
        ) : (
          <div className="divide-y divide-brand-border">
            {recentAnnouncements.map((ann) => (
              <div key={ann.id} className="px-5 py-4 hover:bg-brand-light/50 transition-colors">
                <div className="flex items-start justify-between gap-3">
                  <div className="flex-1 min-w-0">
                    <p className="font-semibold text-sm text-brand-black truncate">{ann.title}</p>
                    <p className="text-xs text-brand-muted mt-1 line-clamp-2">{ann.content}</p>
                  </div>
                  <div className="text-right flex-shrink-0">
                    <p className="text-[10px] text-brand-muted">
                      {formatDistanceToNow(ann.createdAt, { addSuffix: true, locale: nl })}
                    </p>
                    <p className="text-[10px] text-brand-muted mt-0.5">{ann.author.name}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
