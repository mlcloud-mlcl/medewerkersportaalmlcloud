// src/app/dashboard/aankondigingen/AankondigingenForm.tsx
'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { Plus, X, Send } from 'lucide-react'

export function AankondigingenForm() {
  const router = useRouter()
  const [open, setOpen] = useState(false)
  const [loading, setLoading] = useState(false)
  const [form, setForm] = useState({ title: '', content: '', department: 'SUPPORT', pinned: false })

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!form.title || !form.content) return
    setLoading(true)

    try {
      const res = await fetch('/api/announcements', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(form),
      })
      if (!res.ok) throw new Error()
      setOpen(false)
      setForm({ title: '', content: '', department: 'SUPPORT', pinned: false })
      router.refresh()
    } catch {
      alert('Fout bij plaatsen aankondiging')
    } finally {
      setLoading(false)
    }
  }

  if (!open) {
    return (
      <button onClick={() => setOpen(true)} className="btn-primary flex items-center gap-2">
        <Plus size={15} /> Nieuwe aankondiging
      </button>
    )
  }

  return (
    <form onSubmit={handleSubmit} className="card p-5 space-y-4 border-brand-blue">
      <div className="flex items-center justify-between">
        <h3 className="font-bold text-sm text-brand-black">Nieuwe aankondiging</h3>
        <button type="button" onClick={() => setOpen(false)} className="text-brand-muted hover:text-brand-black">
          <X size={16} />
        </button>
      </div>

      <div>
        <label className="label">Titel</label>
        <input value={form.title} onChange={(e) => setForm((p) => ({ ...p, title: e.target.value }))} className="input" placeholder="Aankondiging titel..." />
      </div>

      <div>
        <label className="label">Bericht</label>
        <textarea
          value={form.content}
          onChange={(e) => setForm((p) => ({ ...p, content: e.target.value }))}
          className="input min-h-[100px] resize-none"
          placeholder="Schrijf je aankondiging hier..."
        />
      </div>

      <div className="grid grid-cols-2 gap-3">
        <div>
          <label className="label">Afdeling</label>
          <select value={form.department} onChange={(e) => setForm((p) => ({ ...p, department: e.target.value }))} className="input">
            <option value="SUPPORT">Support</option>
            <option value="MARKETING">Marketing</option>
            <option value="ALL">Iedereen</option>
          </select>
        </div>
        <div className="flex items-end pb-0.5">
          <label className="flex items-center gap-2.5 cursor-pointer">
            <div
              onClick={() => setForm((p) => ({ ...p, pinned: !p.pinned }))}
              className={`w-10 h-5 rounded-full transition-all relative ${form.pinned ? 'bg-brand-blue' : 'bg-brand-border'}`}
            >
              <div className={`absolute top-0.5 w-4 h-4 bg-white rounded-full shadow transition-transform ${form.pinned ? 'translate-x-5' : 'translate-x-0.5'}`} />
            </div>
            <span className="text-sm font-medium text-brand-black">Vastzetten</span>
          </label>
        </div>
      </div>

      <button type="submit" disabled={loading} className="btn-primary flex items-center gap-2 w-full justify-center py-2.5">
        <Send size={14} /> {loading ? 'Plaatsen...' : 'Aankondiging plaatsen'}
      </button>
    </form>
  )
}
