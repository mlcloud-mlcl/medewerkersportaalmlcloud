// src/app/dashboard/aankondigingen/page.tsx
import { getCurrentUser } from '@/lib/auth'
import { db } from '@/lib/db'
import { redirect } from 'next/navigation'
import { Role } from '@prisma/client'
import { Megaphone, Pin } from 'lucide-react'
import { format } from 'date-fns'
import { nl } from 'date-fns/locale'
import { AankondigingenForm } from './AankondigingenForm'

export default async function AankondigingenPage() {
  const user = await getCurrentUser()
  if (!user) redirect('/sign-in')

  const userRole = user.roles.find((r) => r.role === Role.SUPPORT || r.role === Role.BEHEER)
  if (!userRole) redirect('/dashboard')

  // Controleer schrijfpermissie
  const canPost = user.roles.some((r) =>
    r.role === Role.BEHEER ||
    r.canPostAnnouncementsSupport ||
    r.canPostAnnouncementsMarketing
  )

  const announcements = await db.announcement.findMany({
    where: {
      department: {
        in: user.roles.some((r) => r.role === Role.BEHEER)
          ? ['SUPPORT', 'MARKETING', 'ALL']
          : ['SUPPORT', 'ALL'],
      },
    },
    orderBy: [{ pinned: 'desc' }, { createdAt: 'desc' }],
    include: { author: { select: { name: true, avatarUrl: true } } },
  })

  return (
    <div className="max-w-3xl space-y-6">
      <div>
        <h1 className="text-2xl font-extrabold tracking-tight text-brand-black">Aankondigingen</h1>
        <p className="text-brand-muted text-sm mt-1">Interne berichten voor de support afdeling.</p>
      </div>

      {canPost && <AankondigingenForm />}

      <div className="space-y-3">
        {announcements.length === 0 ? (
          <div className="card p-10 text-center text-brand-muted text-sm">Nog geen aankondigingen</div>
        ) : announcements.map((ann) => (
          <div key={ann.id} className={`card p-5 ${ann.pinned ? 'border-brand-blue' : ''}`}>
            {ann.pinned && (
              <div className="flex items-center gap-1.5 text-brand-blue text-xs font-semibold mb-3">
                <Pin size={11} /> Vastgezet
              </div>
            )}
            <h3 className="font-bold text-brand-black">{ann.title}</h3>
            <p className="text-sm text-brand-muted mt-2 leading-relaxed whitespace-pre-wrap">{ann.content}</p>
            <div className="flex items-center gap-3 mt-4 pt-3 border-t border-brand-border">
              <div className="w-6 h-6 rounded-full bg-brand-blue-light flex items-center justify-center">
                <span className="text-brand-blue text-[10px] font-bold">
                  {ann.author.name.charAt(0).toUpperCase()}
                </span>
              </div>
              <p className="text-xs text-brand-muted">
                <strong className="text-brand-black">{ann.author.name}</strong>
                {' · '}{format(new Date(ann.createdAt), 'd MMMM yyyy HH:mm', { locale: nl })}
              </p>
              <span className={`badge ml-auto ${ann.department === 'ALL' ? 'badge-blue' : 'badge-gray'}`}>
                {ann.department === 'ALL' ? 'Iedereen' : ann.department}
              </span>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
