// src/app/dashboard/kennisbank/[id]/page.tsx
import { getCurrentUser } from '@/lib/auth'
import { db } from '@/lib/db'
import { redirect, notFound } from 'next/navigation'
import { Role } from '@prisma/client'
import { ArrowLeft, Edit, Calendar, User } from 'lucide-react'
import Link from 'next/link'
import { format } from 'date-fns'
import { nl } from 'date-fns/locale'

export default async function ArtikelDetailPage({ params }: { params: { id: string } }) {
  const user = await getCurrentUser()
  if (!user) redirect('/sign-in')

  const article = await db.knowledgeArticle.findUnique({
    where: { id: params.id },
    include: { author: { select: { name: true, avatarUrl: true } } },
  })

  if (!article) notFound()

  const isBeheer = user.roles.some((r) => r.role === Role.BEHEER)
  const canEdit = isBeheer || user.roles.some((r) => r.canEditKnowledgeSupport || r.canEditKnowledgeMarketing)

  // Verberg concepten voor niet-beheer
  if (!article.published && !canEdit) notFound()

  // Simpele markdown naar HTML conversie
  const renderContent = (text: string) => {
    return text
      .replace(/^### (.+)$/gm, '<h3 class="text-base font-bold text-brand-black mt-5 mb-2">$1</h3>')
      .replace(/^## (.+)$/gm, '<h2 class="text-lg font-bold text-brand-black mt-6 mb-2">$1</h2>')
      .replace(/^# (.+)$/gm, '<h1 class="text-xl font-bold text-brand-black mt-6 mb-3">$1</h1>')
      .replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
      .replace(/\*(.+?)\*/g, '<em>$1</em>')
      .replace(/`(.+?)`/g, '<code class="bg-brand-light px-1.5 py-0.5 rounded text-sm font-mono text-brand-blue">$1</code>')
      .replace(/^- (.+)$/gm, '<li class="ml-4 list-disc text-brand-muted">$1</li>')
      .replace(/^\d+\. (.+)$/gm, '<li class="ml-4 list-decimal text-brand-muted">$1</li>')
      .replace(/\n\n/g, '</p><p class="mb-3 text-brand-muted leading-relaxed">')
      .replace(/\n/g, '<br/>')
  }

  return (
    <div className="max-w-3xl space-y-6">
      {/* Header */}
      <div className="flex items-center gap-3">
        <Link href="/dashboard/kennisbank" className="w-8 h-8 flex items-center justify-center rounded-lg border border-brand-border hover:bg-brand-light transition-colors">
          <ArrowLeft size={15} className="text-brand-muted" />
        </Link>
        <div className="flex-1">
          <div className="flex items-center gap-2">
            <span className="badge badge-gray text-[10px]">{article.category}</span>
            {!article.published && <span className="badge badge-yellow text-[10px]">Concept</span>}
          </div>
        </div>
        {canEdit && (
          <Link href={`/dashboard/kennisbank/${article.id}/bewerken`} className="btn-secondary flex items-center gap-2 text-xs">
            <Edit size={13} /> Bewerken
          </Link>
        )}
      </div>

      {/* Artikel kaart */}
      <div className="card p-7">
        <h1 className="text-2xl font-extrabold tracking-tight text-brand-black mb-4">{article.title}</h1>

        {/* Meta */}
        <div className="flex items-center gap-4 pb-5 mb-5 border-b border-brand-border">
          <div className="flex items-center gap-2 text-xs text-brand-muted">
            <User size={12} />
            <span>{article.author.name}</span>
          </div>
          <div className="flex items-center gap-2 text-xs text-brand-muted">
            <Calendar size={12} />
            <span>{format(new Date(article.createdAt), 'd MMMM yyyy', { locale: nl })}</span>
          </div>
          <span className={`badge ml-auto ${
            article.department === 'ALL' ? 'badge-blue' :
            article.department === 'SUPPORT' ? 'badge-yellow' : 'badge-green'
          }`}>
            {article.department === 'ALL' ? 'Iedereen' : article.department}
          </span>
        </div>

        {/* Inhoud */}
        <div
          className="prose prose-sm max-w-none text-brand-muted leading-relaxed"
          dangerouslySetInnerHTML={{
            __html: `<p class="mb-3 text-brand-muted leading-relaxed">${renderContent(article.content)}</p>`,
          }}
        />
      </div>
    </div>
  )
}
