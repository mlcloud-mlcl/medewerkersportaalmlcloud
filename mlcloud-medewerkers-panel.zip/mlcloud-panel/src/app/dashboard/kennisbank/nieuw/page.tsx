// src/app/dashboard/kennisbank/nieuw/page.tsx
'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { ArrowLeft, Save, Eye, EyeOff } from 'lucide-react'
import Link from 'next/link'

export default function NieuwArtikelPage() {
  const router = useRouter()
  const [loading, setLoading] = useState(false)
  const [form, setForm] = useState({
    title: '',
    content: '',
    category: '',
    department: 'SUPPORT',
    published: false,
  })

  const handleSubmit = async (publish: boolean) => {
    if (!form.title || !form.content || !form.category) {
      alert('Vul alle velden in.'); return
    }
    setLoading(true)
    try {
      const res = await fetch('/api/knowledge', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...form, published: publish }),
      })
      if (!res.ok) throw new Error()
      router.push('/dashboard/kennisbank')
    } catch {
      alert('Fout bij opslaan')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="max-w-3xl space-y-6">
      <div className="flex items-center gap-3">
        <Link href="/dashboard/kennisbank" className="w-8 h-8 flex items-center justify-center rounded-lg border border-brand-border hover:bg-brand-light transition-colors">
          <ArrowLeft size={15} className="text-brand-muted" />
        </Link>
        <div>
          <h1 className="text-2xl font-extrabold tracking-tight text-brand-black">Nieuw artikel</h1>
          <p className="text-brand-muted text-sm">Voeg een artikel toe aan de kennisbank.</p>
        </div>
      </div>

      <div className="card p-6 space-y-5">
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="label">Titel</label>
            <input
              value={form.title}
              onChange={(e) => setForm((p) => ({ ...p, title: e.target.value }))}
              className="input"
              placeholder="Artikel titel..."
            />
          </div>
          <div>
            <label className="label">Categorie</label>
            <input
              value={form.category}
              onChange={(e) => setForm((p) => ({ ...p, category: e.target.value }))}
              className="input"
              placeholder="bijv. Veelgestelde vragen"
            />
          </div>
        </div>

        <div>
          <label className="label">Afdeling</label>
          <select
            value={form.department}
            onChange={(e) => setForm((p) => ({ ...p, department: e.target.value }))}
            className="input"
          >
            <option value="SUPPORT">Support</option>
            <option value="MARKETING">Marketing</option>
            <option value="ALL">Iedereen</option>
          </select>
        </div>

        <div>
          <label className="label">Inhoud</label>
          <textarea
            value={form.content}
            onChange={(e) => setForm((p) => ({ ...p, content: e.target.value }))}
            className="input min-h-[280px] resize-none font-mono text-sm"
            placeholder="Schrijf je artikel hier... (Markdown ondersteund)"
          />
          <p className="text-xs text-brand-muted mt-1.5">Markdown opmaak wordt ondersteund bij weergave.</p>
        </div>

        <div className="flex gap-3 pt-2">
          <button
            onClick={() => handleSubmit(false)}
            disabled={loading}
            className="btn-secondary flex items-center gap-2"
          >
            <EyeOff size={14} /> Opslaan als concept
          </button>
          <button
            onClick={() => handleSubmit(true)}
            disabled={loading}
            className="btn-primary flex items-center gap-2"
          >
            <Eye size={14} /> Publiceren
          </button>
        </div>
      </div>
    </div>
  )
}
