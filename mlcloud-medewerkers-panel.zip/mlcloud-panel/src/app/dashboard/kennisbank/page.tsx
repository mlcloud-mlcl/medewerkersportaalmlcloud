// src/app/dashboard/kennisbank/page.tsx
import { getCurrentUser } from '@/lib/auth'
import { db } from '@/lib/db'
import { redirect } from 'next/navigation'
import { Role } from '@prisma/client'
import { BookOpen, Plus, FileText } from 'lucide-react'
import Link from 'next/link'
import { format } from 'date-fns'
import { nl } from 'date-fns/locale'

export default async function KennisbankPage() {
  const user = await getCurrentUser()
  if (!user) redirect('/sign-in')

  const hasAccess = user.roles.some((r) =>
    r.role === Role.SUPPORT || r.role === Role.BEHEER
  )
  if (!hasAccess) redirect('/dashboard')

  const isBeheer = user.roles.some((r) => r.role === Role.BEHEER)
  const canEdit = isBeheer || user.roles.some((r) => r.canEditKnowledgeSupport)

  const articles = await db.knowledgeArticle.findMany({
    where: {
      department: { in: ['SUPPORT', 'ALL'] },
      ...(canEdit ? {} : { published: true }),
    },
    orderBy: { createdAt: 'desc' },
    include: { author: { select: { name: true } } },
  })

  // Groepeer op categorie
  const byCategory = articles.reduce((acc, a) => {
    if (!acc[a.category]) acc[a.category] = []
    acc[a.category].push(a)
    return acc
  }, {} as Record<string, typeof articles>)

  return (
    <div className="max-w-3xl space-y-6">
      <div className="flex items-start justify-between">
        <div>
          <h1 className="text-2xl font-extrabold tracking-tight text-brand-black">Kennisbank</h1>
          <p className="text-brand-muted text-sm mt-1">{articles.length} artikel{articles.length !== 1 ? 'en' : ''} beschikbaar voor support medewerkers.</p>
        </div>
        {canEdit && (
          <Link href="/dashboard/kennisbank/nieuw" className="btn-primary flex items-center gap-2">
            <Plus size={15} /> Artikel toevoegen
          </Link>
        )}
      </div>

      {Object.keys(byCategory).length === 0 ? (
        <div className="card p-12 text-center space-y-3">
          <div className="w-12 h-12 bg-brand-blue-light rounded-2xl flex items-center justify-center mx-auto">
            <BookOpen size={22} className="text-brand-blue" />
          </div>
          <p className="font-semibold text-brand-black">Kennisbank is leeg</p>
          <p className="text-sm text-brand-muted">Er zijn nog geen artikelen toegevoegd.</p>
        </div>
      ) : (
        Object.entries(byCategory).map(([category, arts]) => (
          <div key={category} className="space-y-2">
            <h2 className="text-xs font-bold text-brand-muted uppercase tracking-widest px-1">{category}</h2>
            <div className="card overflow-hidden">
              <div className="divide-y divide-brand-border">
                {arts.map((article) => (
                  <Link
                    key={article.id}
                    href={`/dashboard/kennisbank/${article.id}`}
                    className="flex items-center gap-4 px-5 py-4 hover:bg-brand-light/40 transition-colors"
                  >
                    <div className="w-8 h-8 rounded-lg bg-brand-blue-light flex items-center justify-center flex-shrink-0">
                      <FileText size={14} className="text-brand-blue" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-semibold text-sm text-brand-black truncate">{article.title}</p>
                      <p className="text-xs text-brand-muted mt-0.5">
                        {article.author.name} · {format(new Date(article.createdAt), 'd MMM yyyy', { locale: nl })}
                      </p>
                    </div>
                    {!article.published && (
                      <span className="badge badge-yellow flex-shrink-0">Concept</span>
                    )}
                  </Link>
                ))}
              </div>
            </div>
          </div>
        ))
      )}
    </div>
  )
}
