// src/app/api/knowledge/route.ts
import { NextResponse } from 'next/server'
import { getCurrentUser } from '@/lib/auth'
import { db } from '@/lib/db'
import { Role, KnowledgeDept } from '@prisma/client'

export async function POST(req: Request) {
  try {
    const user = await getCurrentUser()
    if (!user) return NextResponse.json({ error: 'Niet ingelogd' }, { status: 401 })

    const isBeheer = user.roles.some((r) => r.role === Role.BEHEER)
    const canEdit = isBeheer || user.roles.some((r) =>
      r.canEditKnowledgeSupport || r.canEditKnowledgeMarketing
    )
    if (!canEdit) return NextResponse.json({ error: 'Geen permissie' }, { status: 403 })

    const { title, content, category, department, published } = await req.json()
    if (!title || !content || !category || !department) {
      return NextResponse.json({ error: 'Ontbrekende velden' }, { status: 400 })
    }

    const article = await db.knowledgeArticle.create({
      data: {
        title,
        content,
        category,
        department: department as KnowledgeDept,
        published: published ?? false,
        authorId: user.id,
      },
    })

    return NextResponse.json(article, { status: 201 })
  } catch (error) {
    console.error('Knowledge article error:', error)
    return NextResponse.json({ error: 'Server fout' }, { status: 500 })
  }
}

export async function GET() {
  try {
    const user = await getCurrentUser()
    if (!user) return NextResponse.json({ error: 'Niet ingelogd' }, { status: 401 })

    const isBeheer = user.roles.some((r) => r.role === Role.BEHEER)

    const articles = await db.knowledgeArticle.findMany({
      where: isBeheer ? {} : { published: true },
      orderBy: { createdAt: 'desc' },
      include: { author: { select: { name: true } } },
    })

    return NextResponse.json(articles)
  } catch (error) {
    return NextResponse.json({ error: 'Server fout' }, { status: 500 })
  }
}
