// src/app/api/payouts/route.ts
import { NextResponse } from 'next/server'
import { getCurrentUser } from '@/lib/auth'
import { db } from '@/lib/db'
import { Role } from '@prisma/client'

export async function POST(req: Request) {
  try {
    const user = await getCurrentUser()
    if (!user) return NextResponse.json({ error: 'Niet ingelogd' }, { status: 401 })

    const hasMarketing = user.roles.some((r) => r.role === Role.MARKETING || r.role === Role.BEHEER)
    if (!hasMarketing) return NextResponse.json({ error: 'Geen toegang' }, { status: 403 })

    const { robloxUser } = await req.json()
    if (!robloxUser) return NextResponse.json({ error: 'Roblox gebruiker vereist' }, { status: 400 })

    // Haal beschikbaar robux op
    const goedgekeurdeLogs = await db.partnerLog.aggregate({
      where: { userId: user.id, status: 'APPROVED' },
      _sum: { robuxAmount: true },
    })

    const totalRobux = goedgekeurdeLogs._sum.robuxAmount ?? 0
    if (totalRobux === 0) {
      return NextResponse.json({ error: 'Geen Robux beschikbaar' }, { status: 400 })
    }

    // Maak uitbetaling aan
    const payout = await db.payoutRequest.create({
      data: {
        userId: user.id,
        robloxUser,
        totalRobux,
        status: 'PENDING',
      },
    })

    return NextResponse.json(payout, { status: 201 })
  } catch (error) {
    console.error('Payout error:', error)
    return NextResponse.json({ error: 'Server fout' }, { status: 500 })
  }
}

export async function GET() {
  try {
    const user = await getCurrentUser()
    if (!user) return NextResponse.json({ error: 'Niet ingelogd' }, { status: 401 })

    const isBeheer = user.roles.some((r) => r.role === Role.BEHEER)

    const payouts = await db.payoutRequest.findMany({
      where: isBeheer ? {} : { userId: user.id },
      orderBy: { createdAt: 'desc' },
      include: { user: { select: { name: true, email: true } } },
    })

    return NextResponse.json(payouts)
  } catch (error) {
    return NextResponse.json({ error: 'Server fout' }, { status: 500 })
  }
}
