// src/app/api/partners/[id]/route.ts
import { NextResponse } from 'next/server'
import { getCurrentUser } from '@/lib/auth'
import { db } from '@/lib/db'
import { Role } from '@prisma/client'

// PATCH: Goedkeuren of afwijzen (beheer only)
export async function PATCH(req: Request, { params }: { params: { id: string } }) {
  try {
    const user = await getCurrentUser()
    if (!user) return NextResponse.json({ error: 'Niet ingelogd' }, { status: 401 })

    const isBeheer = user.roles.some((r) => r.role === Role.BEHEER)
    if (!isBeheer) return NextResponse.json({ error: 'Geen toegang' }, { status: 403 })

    const { status, robuxAmount, reviewNote } = await req.json()

    if (!['APPROVED', 'REJECTED'].includes(status)) {
      return NextResponse.json({ error: 'Ongeldige status' }, { status: 400 })
    }

    const updated = await db.partnerLog.update({
      where: { id: params.id },
      data: {
        status,
        robuxAmount: status === 'APPROVED' ? robuxAmount : null,
        reviewNote,
        reviewedBy: user.clerkId,
        reviewedAt: new Date(),
      },
    })

    return NextResponse.json(updated)
  } catch (error) {
    return NextResponse.json({ error: 'Server fout' }, { status: 500 })
  }
}
