// src/app/api/partners/route.ts
import { NextResponse } from 'next/server'
import { getCurrentUser } from '@/lib/auth'
import { db } from '@/lib/db'
import { MemberRange, Role } from '@prisma/client'

// POST: Nieuw partner log aanmaken
export async function POST(req: Request) {
  try {
    const user = await getCurrentUser()
    if (!user) return NextResponse.json({ error: 'Niet ingelogd' }, { status: 401 })

    const hasMarketing = user.roles.some((r) => r.role === Role.MARKETING || r.role === Role.BEHEER)
    if (!hasMarketing) return NextResponse.json({ error: 'Geen toegang' }, { status: 403 })

    const { serverName, serverLink, memberRange, screenshotUrl } = await req.json()

    if (!serverName || !serverLink || !memberRange || !screenshotUrl) {
      return NextResponse.json({ error: 'Ontbrekende velden' }, { status: 400 })
    }

    const log = await db.partnerLog.create({
      data: {
        userId: user.id,
        serverName,
        serverLink,
        memberRange: memberRange as MemberRange,
        screenshotUrl,
        status: 'PENDING',
      },
    })

    return NextResponse.json(log, { status: 201 })
  } catch (error) {
    console.error('Partner log error:', error)
    return NextResponse.json({ error: 'Server fout' }, { status: 500 })
  }
}

// GET: Haal partner logs op
export async function GET(req: Request) {
  try {
    const user = await getCurrentUser()
    if (!user) return NextResponse.json({ error: 'Niet ingelogd' }, { status: 401 })

    const isBeheer = user.roles.some((r) => r.role === Role.BEHEER)

    const logs = await db.partnerLog.findMany({
      where: isBeheer ? {} : { userId: user.id },
      orderBy: { createdAt: 'desc' },
      include: { user: { select: { name: true, email: true, avatarUrl: true } } },
    })

    return NextResponse.json(logs)
  } catch (error) {
    return NextResponse.json({ error: 'Server fout' }, { status: 500 })
  }
}
