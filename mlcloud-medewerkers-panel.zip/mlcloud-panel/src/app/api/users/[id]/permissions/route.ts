// src/app/api/users/[id]/permissions/route.ts
import { NextResponse } from 'next/server'
import { getCurrentUser } from '@/lib/auth'
import { db } from '@/lib/db'
import { Role } from '@prisma/client'

const ALLOWED_PERMISSIONS = [
  'canPostAnnouncementsSupport',
  'canPostAnnouncementsMarketing',
  'canEditKnowledgeSupport',
  'canEditKnowledgeMarketing',
]

export async function PATCH(req: Request, { params }: { params: { id: string } }) {
  try {
    const admin = await getCurrentUser()
    if (!admin || !admin.roles.some((r) => r.role === Role.BEHEER)) {
      return NextResponse.json({ error: 'Geen toegang' }, { status: 403 })
    }

    const { permission, value } = await req.json()
    if (!ALLOWED_PERMISSIONS.includes(permission)) {
      return NextResponse.json({ error: 'Ongeldige permissie' }, { status: 400 })
    }

    // Update permissie op alle rollen van deze gebruiker
    await db.userRole.updateMany({
      where: { userId: params.id },
      data: { [permission]: value },
    })

    const updated = await db.user.findUnique({
      where: { id: params.id },
      include: { roles: true },
    })

    return NextResponse.json(updated)
  } catch (error) {
    return NextResponse.json({ error: 'Server fout' }, { status: 500 })
  }
}
