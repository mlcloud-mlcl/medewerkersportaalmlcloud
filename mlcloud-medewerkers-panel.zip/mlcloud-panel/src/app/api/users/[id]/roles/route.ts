// src/app/api/users/[id]/roles/route.ts
import { NextResponse } from 'next/server'
import { getCurrentUser } from '@/lib/auth'
import { db } from '@/lib/db'
import { Role } from '@prisma/client'

export async function POST(req: Request, { params }: { params: { id: string } }) {
  try {
    const admin = await getCurrentUser()
    if (!admin || !admin.roles.some((r) => r.role === Role.BEHEER)) {
      return NextResponse.json({ error: 'Geen toegang' }, { status: 403 })
    }

    const { role } = await req.json()
    if (!Object.values(Role).includes(role as Role)) {
      return NextResponse.json({ error: 'Ongeldige rol' }, { status: 400 })
    }

    await db.userRole.upsert({
      where: { userId_role: { userId: params.id, role: role as Role } },
      update: {},
      create: { userId: params.id, role: role as Role },
    })

    const updated = await db.user.findUnique({
      where: { id: params.id },
      include: { roles: true },
    })

    return NextResponse.json(updated)
  } catch (error) {
    return NextResponse.json({ error: 'Server fout' }, { status: 500 })
  }
}

export async function DELETE(req: Request, { params }: { params: { id: string } }) {
  try {
    const admin = await getCurrentUser()
    if (!admin || !admin.roles.some((r) => r.role === Role.BEHEER)) {
      return NextResponse.json({ error: 'Geen toegang' }, { status: 403 })
    }

    const { role } = await req.json()

    await db.userRole.deleteMany({
      where: { userId: params.id, role: role as Role },
    })

    const updated = await db.user.findUnique({
      where: { id: params.id },
      include: { roles: true },
    })

    return NextResponse.json(updated)
  } catch (error) {
    return NextResponse.json({ error: 'Server fout' }, { status: 500 })
  }
}
