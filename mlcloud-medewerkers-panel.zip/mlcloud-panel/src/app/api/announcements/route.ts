// src/app/api/announcements/route.ts
import { NextResponse } from 'next/server'
import { getCurrentUser } from '@/lib/auth'
import { db } from '@/lib/db'
import { Role } from '@prisma/client'

export async function POST(req: Request) {
  try {
    const user = await getCurrentUser()
    if (!user) return NextResponse.json({ error: 'Niet ingelogd' }, { status: 401 })

    const isBeheer = user.roles.some((r) => r.role === Role.BEHEER)
    const canPost = isBeheer || user.roles.some((r) =>
      r.canPostAnnouncementsSupport || r.canPostAnnouncementsMarketing
    )
    if (!canPost) return NextResponse.json({ error: 'Geen permissie' }, { status: 403 })

    const { title, content, department, pinned } = await req.json()
    if (!title || !content || !department) {
      return NextResponse.json({ error: 'Ontbrekende velden' }, { status: 400 })
    }

    const ann = await db.announcement.create({
      data: { title, content, department, pinned: pinned ?? false, authorId: user.id },
    })

    return NextResponse.json(ann, { status: 201 })
  } catch (error) {
    return NextResponse.json({ error: 'Server fout' }, { status: 500 })
  }
}
