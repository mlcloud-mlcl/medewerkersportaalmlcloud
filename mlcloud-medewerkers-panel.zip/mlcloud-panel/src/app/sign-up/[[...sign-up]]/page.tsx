// src/app/sign-up/[[...sign-up]]/page.tsx
import { SignUp } from '@clerk/nextjs'

export default function SignUpPage() {
  return (
    <main className="min-h-screen flex items-center justify-center bg-brand-light p-8">
      <SignUp
        appearance={{
          elements: {
            rootBox: 'w-full max-w-md',
            card: 'shadow-xl border border-brand-border rounded-2xl',
            headerTitle: 'text-2xl font-extrabold text-brand-black tracking-tight',
            headerSubtitle: 'text-brand-muted text-sm',
            formButtonPrimary: 'bg-brand-blue hover:bg-brand-blue-dark font-semibold',
            formFieldInput: 'border border-brand-border rounded-xl text-sm',
            footerActionLink: 'text-brand-blue font-semibold',
          },
        }}
      />
    </main>
  )
}
