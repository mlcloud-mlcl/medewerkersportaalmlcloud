// src/app/sign-in/[[...sign-in]]/page.tsx
import { SignIn } from '@clerk/nextjs'

export default function SignInPage() {
  return (
    <main className="min-h-screen flex">
      {/* Links: branding paneel */}
      <div className="hidden lg:flex w-[420px] min-h-screen bg-brand-black flex-col justify-between p-10 relative overflow-hidden flex-shrink-0">
        {/* Achtergrond decoraties */}
        <div className="absolute top-[-80px] right-[-80px] w-[280px] h-[280px] rounded-full bg-brand-blue/10 pointer-events-none" />
        <div className="absolute bottom-[-60px] left-[-40px] w-[200px] h-[200px] rounded-full bg-brand-blue/6 pointer-events-none" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[400px] h-[400px] rounded-full bg-brand-blue/4 pointer-events-none" />

        {/* Logo */}
        <div className="flex items-center gap-3 relative z-10">
          <div className="w-9 h-9 bg-brand-blue rounded-xl flex items-center justify-center flex-shrink-0">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
              <path d="M3 15a4 4 0 0 0 4 4h9a5 5 0 1 0-.1-9.999 5.002 5.002 0 0 0-9.78 2.096A4.001 4.001 0 0 0 3 15z"/>
            </svg>
          </div>
          <span className="text-white font-bold text-lg tracking-tight">ML Cloud</span>
        </div>

        {/* Tagline */}
        <div className="relative z-10 space-y-3">
          <h2 className="text-white text-3xl font-extrabold leading-tight tracking-tight">
            Jouw werkplek.<br />
            Altijd beschikbaar.
          </h2>
          <p className="text-white/50 text-sm leading-relaxed">
            Beheer partnerlogs, aankondigingen en kennisbank vanuit één centrale plek.
          </p>
        </div>

        {/* Feature badges */}
        <div className="relative z-10 space-y-3">
          {[
            'Beveiligd met Clerk authenticatie',
            'Rol-gebaseerde toegang per afdeling',
            'Partner log beheer & uitbetalingen',
            'Kennisbank & aankondigingen',
          ].map((text) => (
            <div key={text} className="flex items-center gap-3 bg-white/6 border border-white/10 rounded-xl px-4 py-3">
              <div className="w-2 h-2 rounded-full bg-brand-blue flex-shrink-0" />
              <span className="text-white/70 text-sm">{text}</span>
            </div>
          ))}
        </div>

        {/* Footer badge */}
        <div className="relative z-10 flex items-center gap-2">
          <div className="w-1.5 h-1.5 rounded-full bg-green-400 animate-pulse" />
          <span className="text-white/30 text-xs">medewerkers.mlcloud.nl</span>
        </div>
      </div>

      {/* Rechts: Clerk sign-in */}
      <div className="flex-1 flex items-center justify-center p-8 bg-white">
        <div className="w-full max-w-md">
          <SignIn
            appearance={{
              elements: {
                rootBox: 'w-full',
                card: 'shadow-none border-0 p-0 w-full',
                headerTitle: 'text-2xl font-extrabold text-brand-black tracking-tight',
                headerSubtitle: 'text-brand-muted text-sm',
                socialButtonsBlockButton: 'border border-brand-border rounded-xl font-semibold text-sm hover:bg-brand-light transition-colors',
                formFieldInput: 'border border-brand-border rounded-xl text-sm focus:border-brand-blue focus:ring-2 focus:ring-brand-blue/15 py-3',
                formFieldLabel: 'text-xs font-semibold text-brand-black',
                footerActionLink: 'text-brand-blue font-semibold',
              },
            }}
          />
        </div>
      </div>
    </main>
  )
}
