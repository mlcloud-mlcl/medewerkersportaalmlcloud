// src/app/layout.tsx
import { ClerkProvider } from '@clerk/nextjs'
import { Plus_Jakarta_Sans } from 'next/font/google'
import './globals.css'
import type { Metadata } from 'next'

const jakarta = Plus_Jakarta_Sans({
  subsets: ['latin'],
  weight: ['300', '400', '500', '600', '700', '800'],
  variable: '--font-jakarta',
})

export const metadata: Metadata = {
  title: 'ML Cloud | Medewerkers Paneel',
  description: 'Intern medewerkers portaal voor ML Cloud',
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <ClerkProvider>
      <html lang="nl" className={jakarta.variable}>
        <body className="font-sans bg-brand-light text-brand-black antialiased">
          {children}
        </body>
      </html>
    </ClerkProvider>
  )
}
