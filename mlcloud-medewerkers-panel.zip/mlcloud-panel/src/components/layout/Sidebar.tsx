// src/components/layout/Sidebar.tsx
'use client'

import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { clsx } from 'clsx'
import {
  LayoutDashboard, BookOpen, Megaphone, Users, CheckSquare,
  Wallet, UserCog, BarChart2, ChevronDown, ChevronRight,
} from 'lucide-react'
import { useState } from 'react'

type NavItem = {
  label: string
  href: string
  icon: React.ReactNode
  badge?: number
}

type NavSection = {
  title: string
  color: string
  items: NavItem[]
  roles: string[]
}

const sections: NavSection[] = [
  {
    title: 'Support',
    color: 'text-amber-600',
    roles: ['SUPPORT', 'BEHEER'],
    items: [
      { label: 'Dashboard', href: '/dashboard/support', icon: <LayoutDashboard size={15} /> },
      { label: 'Kennisbank', href: '/dashboard/kennisbank', icon: <BookOpen size={15} /> },
      { label: 'Aankondigingen', href: '/dashboard/aankondigingen', icon: <Megaphone size={15} /> },
    ],
  },
  {
    title: 'Marketing',
    color: 'text-green-600',
    roles: ['MARKETING', 'BEHEER'],
    items: [
      { label: 'Dashboard', href: '/dashboard/marketing', icon: <BarChart2 size={15} /> },
      { label: 'Partner loggen', href: '/dashboard/partners/nieuw', icon: <Users size={15} /> },
      { label: 'Uitbetalen', href: '/dashboard/uitbetalen', icon: <Wallet size={15} /> },
    ],
  },
  {
    title: 'Beheer',
    color: 'text-purple-600',
    roles: ['BEHEER'],
    items: [
      { label: 'Dashboard', href: '/dashboard/beheer', icon: <LayoutDashboard size={15} /> },
      { label: 'Partner log goedkeuren', href: '/dashboard/beheer/partners', icon: <CheckSquare size={15} /> },
      { label: 'Uitbetaling beheren', href: '/dashboard/beheer/uitbetalingen', icon: <Wallet size={15} /> },
      { label: 'Gebruikers beheren', href: '/dashboard/beheer/gebruikers', icon: <UserCog size={15} /> },
    ],
  },
]

type Props = {
  userRoles: string[]
}

export function Sidebar({ userRoles }: Props) {
  const pathname = usePathname()
  const [collapsed, setCollapsed] = useState<string[]>([])

  const toggleSection = (title: string) => {
    setCollapsed((prev) =>
      prev.includes(title) ? prev.filter((t) => t !== title) : [...prev, title]
    )
  }

  const visibleSections = sections.filter((s) =>
    s.roles.some((r) => userRoles.includes(r))
  )

  return (
    <aside className="w-[240px] bg-white border-r border-brand-border flex flex-col min-h-[calc(100vh-56px)] flex-shrink-0">
      <div className="flex-1 p-3 space-y-1">
        {visibleSections.map((section) => {
          const isCollapsed = collapsed.includes(section.title)
          return (
            <div key={section.title}>
              {/* Sectie header */}
              <button
                onClick={() => toggleSection(section.title)}
                className="w-full flex items-center justify-between px-2 py-1.5 mb-0.5 group"
              >
                <span className={clsx('text-[10px] font-bold tracking-widest uppercase', section.color)}>
                  {section.title}
                </span>
                {isCollapsed
                  ? <ChevronRight size={12} className="text-brand-muted" />
                  : <ChevronDown size={12} className="text-brand-muted" />
                }
              </button>

              {/* Navigatie items */}
              {!isCollapsed && (
                <div className="space-y-0.5 mb-3">
                  {section.items.map((item) => {
                    const isActive = pathname === item.href
                    return (
                      <Link
                        key={item.href}
                        href={item.href}
                        className={clsx(
                          'flex items-center gap-2.5 px-3 py-2 rounded-lg text-sm font-medium transition-all',
                          isActive
                            ? 'bg-brand-blue-light text-brand-blue'
                            : 'text-brand-muted hover:bg-brand-light hover:text-brand-black'
                        )}
                      >
                        <span className={isActive ? 'text-brand-blue' : 'text-brand-muted'}>
                          {item.icon}
                        </span>
                        <span className="flex-1">{item.label}</span>
                        {item.badge ? (
                          <span className="bg-red-500 text-white text-[10px] font-bold px-1.5 py-0.5 rounded-full">
                            {item.badge}
                          </span>
                        ) : null}
                      </Link>
                    )
                  })}
                </div>
              )}
            </div>
          )
        })}
      </div>

      {/* Versie info */}
      <div className="p-4 border-t border-brand-border">
        <p className="text-[10px] text-brand-muted">ML Cloud Paneel v1.0.0</p>
      </div>
    </aside>
  )
}
