// src/components/layout/Header.tsx
import { UserButton } from '@clerk/nextjs'
import { Bell } from 'lucide-react'

type Props = {
  userName: string
  roles: string[]
  notificationCount?: number
}

const roleBadge = {
  BEHEER: { label: 'Beheer', class: 'bg-purple-50 text-purple-700' },
  MARKETING: { label: 'Marketing', class: 'bg-green-50 text-green-700' },
  SUPPORT: { label: 'Support', class: 'bg-yellow-50 text-yellow-700' },
}

export function Header({ userName, roles, notificationCount = 0 }: Props) {
  // Toon hoogste rol (beheer > marketing > support)
  const primaryRole = roles.includes('BEHEER')
    ? 'BEHEER'
    : roles.includes('MARKETING')
    ? 'MARKETING'
    : 'SUPPORT'

  const badge = roleBadge[primaryRole as keyof typeof roleBadge]

  return (
    <header className="h-14 bg-white border-b border-brand-border flex items-center px-5 gap-4 sticky top-0 z-50">
      {/* Logo */}
      <div className="flex items-center gap-2.5">
        <div className="w-7 h-7 bg-brand-blue rounded-lg flex items-center justify-center flex-shrink-0">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
            <path d="M3 15a4 4 0 0 0 4 4h9a5 5 0 1 0-.1-9.999 5.002 5.002 0 0 0-9.78 2.096A4.001 4.001 0 0 0 3 15z"/>
          </svg>
        </div>
        <span className="font-bold text-sm tracking-tight text-brand-black">ML Cloud</span>
        <span className="text-brand-border">|</span>
        <span className="text-xs text-brand-muted font-medium">Medewerkers Paneel</span>
      </div>

      <div className="flex-1" />

      {/* Rol badge */}
      {badge && (
        <span className={`text-[11px] font-bold px-2.5 py-1 rounded-full tracking-wide ${badge.class}`}>
          {badge.label}
        </span>
      )}

      {/* Notificaties */}
      <button className="relative w-8 h-8 flex items-center justify-center rounded-lg hover:bg-brand-light transition-colors">
        <Bell size={16} className="text-brand-muted" />
        {notificationCount > 0 && (
          <span className="absolute top-1 right-1 w-4 h-4 bg-red-500 text-white text-[9px] font-bold rounded-full flex items-center justify-center">
            {notificationCount > 9 ? '9+' : notificationCount}
          </span>
        )}
      </button>

      {/* Gebruiker info + Clerk knop */}
      <div className="flex items-center gap-2.5 pl-2 border-l border-brand-border">
        <span className="text-xs font-semibold text-brand-black hidden sm:block">{userName}</span>
        <UserButton
          afterSignOutUrl="/sign-in"
          appearance={{
            elements: {
              avatarBox: 'w-8 h-8 rounded-lg',
            },
          }}
        />
      </div>
    </header>
  )
}
