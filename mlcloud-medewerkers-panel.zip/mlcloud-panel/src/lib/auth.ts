// src/lib/auth.ts
import { auth, currentUser } from '@clerk/nextjs/server'
import { db } from './db'
import { Role } from '@prisma/client'

// Haal de huidige gebruiker op uit de database (aanmaken als niet bestaat)
export async function getCurrentUser() {
  const { userId } = auth()
  if (!userId) return null

  const clerkUser = await currentUser()
  if (!clerkUser) return null

  // Upsert: maak aan als niet bestaat
  const user = await db.user.upsert({
    where: { clerkId: userId },
    update: {
      name: `${clerkUser.firstName ?? ''} ${clerkUser.lastName ?? ''}`.trim() || clerkUser.username || 'Gebruiker',
      avatarUrl: clerkUser.imageUrl,
    },
    create: {
      clerkId: userId,
      email: clerkUser.emailAddresses[0]?.emailAddress ?? '',
      name: `${clerkUser.firstName ?? ''} ${clerkUser.lastName ?? ''}`.trim() || clerkUser.username || 'Gebruiker',
      avatarUrl: clerkUser.imageUrl,
    },
    include: { roles: true },
  })

  return user
}

// Check of gebruiker een specifieke rol heeft
export async function hasRole(role: Role): Promise<boolean> {
  const user = await getCurrentUser()
  if (!user) return false
  return user.roles.some((r) => r.role === role)
}

// Check of gebruiker beheerder is
export async function isBeheer(): Promise<boolean> {
  return hasRole(Role.BEHEER)
}

// Haal gebruiker op met roles (throw als niet ingelogd)
export async function requireUser() {
  const user = await getCurrentUser()
  if (!user) throw new Error('Niet ingelogd')
  return user
}

// Haal gebruiker op met specifieke rol vereist
export async function requireRole(role: Role) {
  const user = await requireUser()
  const hasTheRole = user.roles.some((r) => r.role === role)
  if (!hasTheRole) throw new Error(`Geen toegang: rol ${role} vereist`)
  return user
}
